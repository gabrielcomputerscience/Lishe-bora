import Link from "next/link";
import { Vein } from "@/components/Brand";
import { NewsCard } from "@/components/NewsCard";
import { NoticeTable } from "@/components/NoticeTable";
import { publicGet } from "@/lib/server";
import type { NewsItem, Notice } from "@/lib/types";

type Home = {
  hero: { eyebrow?: string; title?: string; subtitle?: string; cta_label?: string };
  stats: { show: boolean; items: { value: string; label: string }[] } | null;
  news: NewsItem[]; notices: Notice[];
};

const STEPS = [
  ["Schools plan", "Schools enter enrolment, menus and stock. The platform works out what food is needed."],
  ["Opportunities are published", "Demand is combined across schools and posted as open, fair sourcing notices."],
  ["Local suppliers bid", "Registered farmers, groups and traders bid. Bids are sealed until the deadline."],
  ["Deliver, verify, get paid", "Quality is checked, schools confirm receipt, and payment is tracked to settlement."],
];

export default async function HomePage() {
  const d = await publicGet<Home>("/home");
  const hero = d?.hero ?? {};
  return (
    <>
      <section className="hero">
        <Vein />
        <div className="wrap hero-in">
          <div className="eyebrow">{hero.eyebrow ?? "STEP School Feeding Project"}</div>
          <h1>{hero.title ?? "Nutritious school meals, sourced from local farmers"}</h1>
          {hero.subtitle && <p>{hero.subtitle}</p>}
          <div className="row">
            <Link className="btn gold lg" href="/register">{hero.cta_label ?? "Register as a supplier"}</Link>
            <Link className="btn lg ghost" href="/opportunities">View open opportunities</Link>
          </div>
        </div>
      </section>
      {d?.stats && (
        <section className="wrap stats">
          {d.stats.items.map((s) => <div key={s.label}><b>{s.value}</b><span>{s.label}</span></div>)}
        </section>
      )}
      <section className="wrap sec">
        <h2 style={{ marginBottom: 16 }}>How LisheBora works</h2>
        <div className="grid g4">{STEPS.map(([t, x], i) => (
          <div key={t} className="card howc"><span className="n">{i + 1}</span><h3>{t}</h3><p className="muted small">{x}</p></div>))}</div>
      </section>
      <section className="wrap sec" style={{ paddingTop: 0 }}>
        <div className="row" style={{ marginBottom: 14 }}><h2>Open opportunities</h2><span className="spacer" /><Link href="/opportunities">See all →</Link></div>
        <NoticeTable rows={d?.notices ?? []} />
      </section>
      {!!d?.news.length && (
        <section className="wrap sec" style={{ paddingTop: 0 }}>
          <div className="row" style={{ marginBottom: 14 }}><h2>News &amp; updates</h2><span className="spacer" /><Link href="/news">All news →</Link></div>
          <div className="grid g3">{d.news.map((n) => <NewsCard key={n.slug} n={n} />)}</div>
        </section>
      )}
      <section className="band">
        <div className="wrap row" style={{ justifyContent: "space-between" }}>
          <div><h2>Are you a farmer, cooperative or trader?</h2>
            <p style={{ margin: "6px 0 0", color: "#E4ECDC" }}>Register once and receive SMS alerts for new opportunities in your area. Assisted registration is available.</p></div>
          <Link className="btn gold lg" href="/register">Register now</Link>
        </div>
      </section>
      {!d && <div className="wrap alert warn">The platform API is not reachable. Start the backend (see README).</div>}
    </>
  );
}
