import { notFound } from "next/navigation";
import { Markdown } from "@/components/Markdown";
import { publicGet } from "@/lib/server";

export async function CmsPage({ slug }: { slug: string }) {
  const pg = await publicGet<{ title: string; body: string }>(`/pages/${slug}`);
  if (!pg) notFound();
  return (<section className="wrap sec narrow"><h1>{pg.title}</h1><div style={{ marginTop: 14 }}><Markdown>{pg.body}</Markdown></div></section>);
}
