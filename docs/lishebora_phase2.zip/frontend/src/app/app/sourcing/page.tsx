"use client";
import { useCallback, useEffect, useState } from "react";
import { ErrorBox, Field, PageHead, Pill, useToast } from "@/components/ui";
import { get, post } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fmtDateTime } from "@/lib/format";

type Ev = { id: string; reference: string; title: string; method: string; eligibility: string; closes_at: string; status: string; is_public: boolean; county_id: string | null };
export default function Sourcing() {
  const { can } = useAuth();
  const [rows, setRows] = useState<Ev[]>([]);
  const [counties, setCounties] = useState<{ id: string; name: string }[]>([]);
  const [f, setF] = useState({ reference: "", title: "", method: "rfq", county_id: "", eligibility: "", closes_at: "", is_public: true });
  const [err, setErr] = useState<unknown>(null);
  const { toast, node } = useToast();
  const load = useCallback(() => get<Ev[]>("/procurement-events").then(setRows).catch(setErr), []);
  useEffect(() => { load(); get<{ id: string; name: string }[]>("/public/counties").then(setCounties).catch(() => {}); }, [load]);
  const run = async (fn: () => Promise<unknown>, ok: string) => { setErr(null); try { await fn(); toast(ok); load(); } catch (e) { setErr(e); } };
  return (
    <>
      <PageHead crumb="Source › Sourcing events" title="Sourcing events" sub="Phase 1: create and publish notices. Bids, sealed opening and evaluation arrive in Phase 3." />
      <ErrorBox error={err} />
      <div className="grid" style={{ gridTemplateColumns: "2fr 1fr", alignItems: "start" }}>
        <div className="card"><div className="tablewrap"><table><thead><tr><th>Reference</th><th>Title</th><th>Method</th><th>Closes</th><th>Status</th><th /></tr></thead>
          <tbody>{rows.map((e) => <tr key={e.id}><td><b>{e.reference}</b></td><td>{e.title}<div className="small muted">{e.eligibility}</div></td><td>{e.method.toUpperCase()}</td>
            <td className="small">{fmtDateTime(e.closes_at)}</td><td><Pill status={e.status} /></td>
            <td className="r">{e.status === "draft" && can("src:submit") && <button className="btn sm primary" onClick={() => run(() => post(`/procurement-events/${e.id}/publish`), "Published to website")}>Publish</button>}</td></tr>)}
            {!rows.length && <tr><td colSpan={6} className="muted">No events yet.</td></tr>}</tbody></table></div></div>
        {can("src:create") && <form className="card" onSubmit={(e) => { e.preventDefault(); run(async () => { await post("/procurement-events", { ...f, county_id: f.county_id || null, closes_at: new Date(f.closes_at).toISOString() }); setF({ ...f, reference: "", title: "" }); }, "Draft event created"); }}>
          <h3>New sourcing event</h3>
          <Field label="Reference"><input value={f.reference} onChange={(e) => setF({ ...f, reference: e.target.value })} placeholder="RFQ-2026-A-0044" /></Field>
          <Field label="Title"><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
          <Field label="Method"><select value={f.method} onChange={(e) => setF({ ...f, method: e.target.value })}><option value="rfq">RFQ</option><option value="competitive">Competitive bid</option><option value="framework">Framework</option><option value="call_off">Call-off</option><option value="direct">Direct (under threshold)</option></select></Field>
          <Field label="County"><select value={f.county_id} onChange={(e) => setF({ ...f, county_id: e.target.value })}><option value="">—</option>{counties.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
          <Field label="Eligibility"><input value={f.eligibility} onChange={(e) => setF({ ...f, eligibility: e.target.value })} placeholder="Prequalified: cereals" /></Field>
          <Field label="Closes at"><input type="datetime-local" value={f.closes_at} onChange={(e) => setF({ ...f, closes_at: e.target.value })} /></Field>
          <label className="chk" style={{ marginBottom: 12 }}><input type="checkbox" checked={f.is_public} onChange={(e) => setF({ ...f, is_public: e.target.checked })} /> Show on public website when published</label>
          <button className="btn primary" disabled={!f.reference || !f.title || !f.closes_at}>Create draft</button></form>}
      </div>
      {node}
    </>
  );
}
