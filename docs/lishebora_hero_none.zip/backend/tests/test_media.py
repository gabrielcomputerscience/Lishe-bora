"""Website images: upload, use as a section/page background, publish, serve publicly, protect images in use."""
import base64

from tests.conftest import login

A = "/api/v1"
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")


def test_backgrounds(client):
    ah = login(client, "administrator@demo.lishebora", "Demo!2026pass")
    assert client.post(f"{A}/cms/media", headers=ah, files={"file": ("x.pdf", b"%PDF-1.4 x", "application/pdf")}).status_code == 415
    vid = client.post(f"{A}/cms/media", headers=ah, files={"file": ("v.mp4", b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 64, "video/mp4")}).json()
    assert vid["content_type"] == "video/mp4"
    bad = client.put(f"{A}/cms/blocks/backgrounds", headers=ah, json={"data": {"home_band": {"media_id": vid["id"]}}})
    assert bad.status_code == 422
    m = client.post(f"{A}/cms/media", headers=ah, data={"title": "Farmers at a market", "alt": "Farmers selling maize"},
                    files={"file": ("m.png", PNG, "image/png")})
    assert m.status_code == 201, m.text
    mid = m.json()["id"]
    slots = {s["key"] for s in client.get(f"{A}/cms/backgrounds/slots", headers=ah).json()}
    assert {"home_hero", "page:where-we-work"} <= slots
    data = {"home_hero": {"media_id": mid, "overlay": 150, "position": "top"}, "bogus": {"media_id": mid}, "page:faq": {"media_id": ""},
            "home_hero_media": {"media_id": vid["id"]}}
    b = client.put(f"{A}/cms/blocks/backgrounds", headers=ah, json={"data": data}).json()
    assert sorted(b["data"]) == ["home_hero", "home_hero_media"] and b["data"]["home_hero"]["overlay"] == 90
    assert b["data"]["home_hero_media"]["kind"] == "video"
    off = client.put(f"{A}/cms/blocks/backgrounds", headers=ah, json={"data": {**data, "home_hero_media": {"hidden": True}}}).json()
    assert off["data"]["home_hero_media"] == {"hidden": True}
    client.put(f"{A}/cms/blocks/backgrounds", headers=ah, json={"data": data})
    assert client.get(f"{A}/public/backgrounds").json() == {}                   # not live until published
    client.post(f"{A}/cms/blocks/backgrounds/workflow", headers=ah, json={"action": "publish"})
    live = client.get(f"{A}/public/backgrounds").json()["home_hero"]
    img = client.get(live["url"])
    assert img.status_code == 200 and img.headers["content-type"] == "image/png" and img.content == PNG
    assert client.delete(f"{A}/cms/media/{mid}", headers=ah).json()["error"]["code"] == "IMAGE_IN_USE"
    # editors can upload but only approvers delete
    eh = login(client, "editor@demo.lishebora", "Demo!2026pass")
    assert client.delete(f"{A}/cms/media/{mid}", headers=eh).status_code == 403
