from fastapi import APIRouter

from app.api.v1 import audit, auth, budget, cms, iam, masterdata, planning, procurement, public, suppliers, workflow

api_router = APIRouter(prefix="/api/v1")
for r in (auth.router, public.router, iam.router, masterdata.router, suppliers.router, procurement.router,
          cms.router, audit.router, planning.router, budget.router, workflow.router):
    api_router.include_router(r)
