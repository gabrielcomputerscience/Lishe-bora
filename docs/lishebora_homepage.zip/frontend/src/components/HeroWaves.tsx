/** Animated hero artwork: a diamond "window" filled with moving waves (blue, cyan, yellow, brown), nested diamond
 *  outlines with circuit-style nodes, and a full-width wave band along the bottom of the hero.
 *  Pure SVG + CSS (no GIF): sharp on every screen, a few KB, and it stops moving for people who ask for reduced motion. */

// A repeating wave path twice the visible width, so sliding it by half its width loops seamlessly.
function wave(width: number, height: number, base: number, amp: number, length: number) {
  let d = `M0 ${base}`;
  for (let x = 0; x < width * 2; x += length) {
    d += ` Q ${x + length / 4} ${base - amp} ${x + length / 2} ${base} T ${x + length} ${base}`;
  }
  return `${d} L ${width * 2} ${height} L 0 ${height} Z`;
}

const LAYERS = [
  { color: "#1F5FA8", base: 250, amp: 20, len: 200, dur: 14, rev: false, op: 0.95 },   // deep blue
  { color: "#1FB5C9", base: 305, amp: 18, len: 160, dur: 10, rev: true, op: 0.9 },     // cyan
  { color: "#F9B916", base: 365, amp: 16, len: 180, dur: 12, rev: false, op: 0.92 },   // AATF amber / yellow
  { color: "#8A5A2B", base: 425, amp: 14, len: 140, dur: 9, rev: true, op: 0.95 },     // earth brown
];

export function HeroDiamond() {
  const W = 600;
  return (
    <svg className="hero-diamond" viewBox="0 0 600 600" role="img" aria-label="Decorative waves inside a diamond">
      <defs>
        <clipPath id="dmd"><polygon points="300,40 560,300 300,560 40,300" /></clipPath>
        <linearGradient id="dsky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0E2F4F" /><stop offset="1" stopColor="#1B4A6B" />
        </linearGradient>
      </defs>
      {/* outer lattice */}
      <polygon points="300,6 594,300 300,594 6,300" className="dm-line" />
      <polygon points="300,40 560,300 300,560 40,300" fill="url(#dsky)" />
      <g clipPath="url(#dmd)">
        <circle cx="400" cy="170" r="34" fill="#F9B916" opacity=".85" className="dm-sun" />
        {LAYERS.map((l, i) => (
          <path key={i} d={wave(W, 600, l.base, l.amp, l.len)} fill={l.color} opacity={l.op}
                className={`dm-wave ${l.rev ? "rev" : ""}`} style={{ animationDuration: `${l.dur}s` }} />
        ))}
      </g>
      <polygon points="300,40 560,300 300,560 40,300" className="dm-edge" />
      <polygon points="300,110 490,300 300,490 110,300" className="dm-inner" />
      {/* nodes at the corners, like the AATF circuit motif */}
      {[[300, 6], [594, 300], [300, 594], [6, 300]].map(([x, y]) => (
        <rect key={`${x}-${y}`} x={x - 9} y={y - 9} width="18" height="18" transform={`rotate(45 ${x} ${y})`} className="dm-node" />
      ))}
      {[[140, 120, 0], [470, 470, 1.5], [505, 150, 3]].map(([x, y, d]) => (
        <rect key={`f${x}`} x={x - 7} y={y - 7} width="14" height="14" transform={`rotate(45 ${x} ${y})`} className="dm-float"
              style={{ animationDelay: `${d}s` }} />
      ))}
    </svg>
  );
}

export function HeroWaveBand() {
  const W = 1440, H = 120;
  const band = [
    { color: "#1F5FA8", base: 40, amp: 14, len: 360, dur: 18, rev: false, op: 0.55 },
    { color: "#1FB5C9", base: 58, amp: 12, len: 300, dur: 13, rev: true, op: 0.6 },
    { color: "#F9B916", base: 76, amp: 10, len: 320, dur: 16, rev: false, op: 0.75 },
    { color: "var(--bg)", base: 92, amp: 10, len: 280, dur: 11, rev: true, op: 1 },
  ];
  return (
    <svg className="hero-band" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" aria-hidden="true">
      {band.map((l, i) => (
        <path key={i} d={wave(W, H, l.base, l.amp, l.len)} style={{ fill: l.color, animationDuration: `${l.dur}s` }} opacity={l.op}
              className={`dm-wave ${l.rev ? "rev" : ""}`} />
      ))}
    </svg>
  );
}
