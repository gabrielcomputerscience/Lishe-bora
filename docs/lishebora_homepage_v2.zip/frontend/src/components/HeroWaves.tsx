/** Moving wave band along the bottom of banners, in the AATF brand colours (Brand Manual p.10). Pure SVG + CSS;
 *  it stops moving for people who ask for reduced motion. */
function wave(width: number, height: number, base: number, amp: number, length: number) {
  let d = `M0 ${base}`;
  for (let x = 0; x < width * 2; x += length) d += ` Q ${x + length / 4} ${base - amp} ${x + length / 2} ${base} T ${x + length} ${base}`;
  return `${d} L ${width * 2} ${height} L 0 ${height} Z`;
}

export function HeroWaveBand() {
  const W = 1440, H = 120;
  const band = [
    { color: "#75BA43", base: 40, amp: 14, len: 360, dur: 18, rev: false, op: 0.55 },   // leaf green
    { color: "#AB822D", base: 58, amp: 12, len: 300, dur: 13, rev: true, op: 0.7 },     // gold
    { color: "#F9B916", base: 76, amp: 10, len: 320, dur: 16, rev: false, op: 0.85 },   // amber
    { color: "var(--bg)", base: 92, amp: 10, len: 280, dur: 11, rev: true, op: 1 },
  ];
  return (
    <svg className="hero-band" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" aria-hidden="true">
      {band.map((l, i) => (
        <path key={i} d={wave(W, H, l.base, l.amp, l.len)} style={{ fill: l.color, animationDuration: `${l.dur}s` }} opacity={l.op}
              className={`dm-wave ${l.rev ? "rev" : ""}`} />))}
    </svg>
  );
}
