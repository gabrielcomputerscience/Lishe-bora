"""Notification channels. Development: messages are logged to the console.
Replace ConsoleSender with an SMS gateway / email provider adapter in production (SRS §10.2)."""
import logging

log = logging.getLogger("lishebora.notify")


class ConsoleSender:
    def sms(self, phone: str, text: str) -> None:
        log.warning("[SMS → %s] %s", phone, text)
        print(f"[SMS -> {phone}] {text}", flush=True)

    def email(self, to: str, subject: str, text: str) -> None:
        log.warning("[EMAIL → %s] %s: %s", to, subject, text)
        print(f"[EMAIL -> {to}] {subject}: {text}", flush=True)


sender = ConsoleSender()


def mask_phone(p: str | None) -> str:
    if not p:
        return ""
    return p[:3] + "•" * max(0, len(p) - 6) + p[-3:]
