"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { PageHead } from "@/components/ui";

export default function TraceSearch() {
  const [code, setCode] = useState("");
  const router = useRouter();
  return (
    <>
      <PageHead crumb="Fulfil" title="Traceability" sub="Follow a batch from the farmers who supplied it, through inspection and storage, to the schools that received it." />
      <form className="card" style={{ maxWidth: 520 }} onSubmit={(e) => { e.preventDefault(); if (code.trim()) router.push(`/app/trace/${code.trim().toUpperCase()}`); }}>
        <div className="field"><label htmlFor="bc">Batch code</label><input id="bc" value={code} onChange={(e) => setCode(e.target.value)} placeholder="BATCH-2026-000001" /></div>
        <button className="btn primary" type="submit">Trace</button>
      </form>
    </>
  );
}
