"""Phase-1 slice: sourcing events so notices can be published. Bids/evaluation arrive in Phase 3."""
import uuid
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import Principal, ensure_in_scope, require, scope_for
from app.core.errors import AppError
from app.models import EventStatus, ProcurementEvent, ProcurementMethod
from app.schemas.common import ORM
from app.services import audit

router = APIRouter(prefix="/procurement-events", tags=["procurement"])


class EventIn(BaseModel):
    reference: str = Field(min_length=3, max_length=40)
    title: str
    method: ProcurementMethod
    county_id: uuid.UUID | None = None
    description: str = ""
    eligibility: str = ""
    categories: list[str] = Field(default_factory=list)
    estimated_value: Decimal | None = None
    closes_at: datetime
    is_public: bool = True


class EventOut(ORM, EventIn):
    id: uuid.UUID
    status: str


@router.get("", response_model=list[EventOut])
def list_events(p: Principal = Depends(require("src:view")), db: Session = Depends(get_db)):
    stmt = select(ProcurementEvent)
    allowed = scope_for(db, p, "src:view")
    if allowed is not None:
        stmt = stmt.where(or_(ProcurementEvent.county_id.in_(allowed), ProcurementEvent.county_id.is_(None)))
    return db.scalars(stmt.order_by(ProcurementEvent.closes_at.desc())).all()


@router.post("", response_model=EventOut, status_code=201)
def create_event(body: EventIn, request: Request, p: Principal = Depends(require("src:create")), db: Session = Depends(get_db)):
    if body.county_id:
        ensure_in_scope(db, p, "src:create", body.county_id)
    if db.scalar(select(ProcurementEvent).where(ProcurementEvent.reference == body.reference)):
        raise AppError(409, "CODE_IN_USE", "This reference is already used.")
    e = ProcurementEvent(**body.model_dump(), created_by=p.id)
    db.add(e)
    db.flush()
    audit.record(db, action="CREATE", entity="procurement_event", entity_id=e.id, user=p.user,
                 after=body.model_dump(), request=request)
    db.commit()
    return e


@router.post("/{eid}/publish", response_model=EventOut)
def publish(eid: uuid.UUID, request: Request, p: Principal = Depends(require("src:submit")), db: Session = Depends(get_db)):
    """Interim: publishes directly. Phase 3 routes this through the workflow engine (approval by threshold)."""
    e = db.get(ProcurementEvent, eid)
    if e is None:
        raise AppError(404, "NOT_FOUND", "Event not found.")
    if e.status != EventStatus.draft:
        raise AppError(409, "INVALID_TRANSITION", "Only draft events can be published.")
    e.status = EventStatus.open
    audit.record(db, action="PUBLISH", entity="procurement_event", entity_id=e.id, user=p.user,
                 before={"status": "draft"}, after={"status": "open"}, request=request)
    db.commit()
    return e
