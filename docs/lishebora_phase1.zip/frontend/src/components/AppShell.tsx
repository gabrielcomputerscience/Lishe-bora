"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { Logo, Vein } from "./Brand";

type Item = { href: string; label: string; group: string; show: (can: (...p: string[]) => boolean, hasSupplier: boolean) => boolean };
const NAV: Item[] = [
  { href: "/app", label: "Dashboard", group: "Overview", show: () => true },
  { href: "/app/my-supplier", label: "My supplier profile", group: "Supplier", show: (_c, s) => s },
  { href: "/app/suppliers", label: "Supplier registry", group: "Source", show: (c) => c("sup:view") },
  { href: "/app/sourcing", label: "Sourcing events", group: "Source", show: (c) => c("src:create", "src:view") },
  { href: "/app/users", label: "Users & roles", group: "Administration", show: (c) => c("iam:view") },
  { href: "/app/website", label: "Website content", group: "Administration", show: (c) => c("cms:view") },
  { href: "/app/audit", label: "Audit trail", group: "Oversight", show: (c) => c("aud:view") },
  { href: "/app/profile", label: "My profile & security", group: "Account", show: () => true },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const { me, loading, can, signOut } = useAuth();
  const router = useRouter();
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => { if (!loading && !me) router.replace(`/sign-in?next=${encodeURIComponent(path)}`); }, [loading, me, router, path]);
  useEffect(() => setOpen(false), [path]);
  if (loading || !me) return <div className="wrap sec muted">Loading…</div>;

  const items = NAV.filter((i) => i.show(can, !!me.supplier_id));
  const initials = me.full_name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const primary = me.roles[0];
  let grp = "";
  return (
    <>
      <header className="top">
        <button className="iconbtn menu-toggle" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
        <Link href="/app"><Logo /></Link>
        <div className="product"><b>LisheBora</b><span>School food e-Sourcing Platform</span></div>
        <span className="spacer" />
        <Link className="btn sm" href="/">Website</Link>
        <div className="avatar" title={me.full_name}>{initials}</div>
        <button className="btn sm" onClick={async () => { await signOut(); window.location.assign("/"); }}>Sign out</button>
      </header>
      <div className="shell">
        <nav className={`side ${open ? "open" : ""}`} aria-label="Portal">
          {items.map((i) => {
            const head = i.group !== grp ? <div className="grp">{(grp = i.group)}</div> : null;
            const active = i.href === "/app" ? path === "/app" : path.startsWith(i.href);
            return <div key={i.href}>{head}<Link className="nav" href={i.href} aria-current={active ? "page" : undefined}>{i.label}</Link></div>;
          })}
          <div className="grp" style={{ marginTop: 18 }}>Signed in</div>
          <div style={{ padding: "0 12px", fontSize: 13, lineHeight: 1.4, position: "relative", zIndex: 1 }}>
            <b style={{ color: "#fff" }}>{me.full_name}</b><br />
            {me.roles.map((r) => <span key={r.role + r.org_id} style={{ color: "#C9D6BE", display: "block" }}>{r.role_name}{r.org_name ? ` · ${r.org_name}` : ""}</span>)}
            {!primary && <span style={{ color: "#C9D6BE" }}>No role assigned</span>}
          </div>
          <Vein stroke="#F9B916" width={9} />
        </nav>
        <main className="main" id="main">{children}</main>
      </div>
    </>
  );
}
