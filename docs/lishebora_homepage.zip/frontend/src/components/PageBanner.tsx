import { HeroDiamond, HeroWaveBand } from "./HeroWaves";

/** Page header used across the public website: brand gradient, the wave diamond and the moving wave band. */
export function PageBanner({ eyebrow, title, sub, children }: { eyebrow?: string; title: string; sub?: string; children?: React.ReactNode }) {
  return (
    <section className="hero pbanner">
      <HeroDiamond />
      <div className="wrap hero-in">
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        {sub && <p>{sub}</p>}
        {children}
      </div>
      <HeroWaveBand />
    </section>
  );
}
