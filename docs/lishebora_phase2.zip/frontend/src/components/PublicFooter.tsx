/* eslint-disable @next/next/no-img-element */
import Link from "next/link";


export function PublicFooter() {
  return (
    <footer className="sfoot">
      <div className="wrap fgrid">
        <div><span className="flogo"><img src="/brand/aatf-logo-tagline.png" alt="AATF — Prosperity through technology" style={{ height: 48, display: "block" }} /></span>
          <p className="small" style={{ marginTop: 12 }}>LisheBora e-Sourcing Platform · STEP School Feeding Project</p></div>
        <div><b>Platform</b><Link href="/opportunities">Opportunities</Link><Link href="/how-it-works">How it works</Link>
          <Link href="/resources">Resources</Link><Link href="/faq">FAQ</Link></div>
        <div><b>Help</b><Link href="/contact">Contact &amp; grievances</Link><Link href="/p/privacy">Privacy notice</Link>
          <Link href="/p/terms">Terms of use</Link></div>
        <div><b>Helpdesk</b><span>[Phone / SMS short code]</span><span>[Email address]</span><span>English · Kiswahili</span></div>
      </div>
    </footer>
  );
}
