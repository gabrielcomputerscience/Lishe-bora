import Link from "next/link";
import { CountUp } from "@/components/CountUp";
import { HeroDiamond, HeroWaveBand } from "@/components/HeroWaves";
import { NewsCard } from "@/components/NewsCard";
import { NoticeTable } from "@/components/NoticeTable";
import { colourFor } from "@/lib/food";
import { publicGet } from "@/lib/server";
import type { FoodCategory, NewsItem, Notice } from "@/lib/types";

type Home = {
  hero: { eyebrow?: string; title?: string; subtitle?: string; cta_label?: string };
  stats: { show: boolean; items: { value: string; label: string }[] } | null;
  live: { key: string; value: number; label: string }[] | null;
  news: NewsItem[]; notices: Notice[];
};
type Area = { name: string; code: string; schools: number; sub_counties: { name: string; schools: string[] }[] };

const STEPS = [
  ["Schools plan", "Schools enter enrolment, menus and stock. The platform works out what food is needed."],
  ["Opportunities are published", "Demand is combined across schools and posted as open, fair sourcing notices."],
  ["Local suppliers bid", "Registered farmers, groups and traders bid. Bids are sealed until the deadline."],
  ["Deliver, verify, get paid", "Quality is checked, schools confirm receipt, and payment is tracked to settlement."],
];
const AUDIENCES = [
  ["Farmers, cooperatives & traders", "Register once, get SMS alerts for matching opportunities, bid online and track your payments.", "/p/for-suppliers", "#F9B916", "For suppliers"],
  ["Schools", "Plan each term's food, check menus for variety, confirm deliveries on a phone even without network.", "/p/for-schools", "#1FB5C9", "For schools"],
  ["Counties & partners", "Run open procurement within budget, with approvals, sealed bids, quality checks and a full audit trail.", "/p/for-counties", "#1F5FA8", "For counties"],
] as const;
const FEATURES = [
  ["Open and fair", "Every notice publishes its criteria in advance, and award decisions are made public."],
  ["Sealed bids", "Bids are encrypted and stay closed until they are opened together after the deadline."],
  ["Works on any phone", "SMS alerts and one-time codes; delivery confirmation works offline and syncs later."],
  ["Quality you can trace", "Batches are inspected and labelled with QR codes, from the farmer group to the school kitchen."],
  ["Paid on time", "Invoices are matched to accepted deliveries, and suppliers can follow payment to settlement."],
  ["Inclusive by design", "Women-, youth- and PWD-led enterprises can declare their status, so inclusion can be monitored."],
];
const ACCENT = ["#1F5FA8", "#1FB5C9", "#F9B916", "#8A5A2B"];

export default async function HomePage() {
  const [d, cats, areas, faq] = await Promise.all([
    publicGet<Home>("/home"), publicGet<FoodCategory[]>("/food-categories"), publicGet<Area[]>("/pilot-areas"),
    publicGet<{ question: string; answer: string }[]>("/faq"),
  ]);
  const hero = d?.hero ?? {};
  return (
    <>
      <section className="hero">
        <HeroDiamond />
        <div className="wrap hero-in">
          <div className="eyebrow">{hero.eyebrow ?? "STEP School Feeding Project"}</div>
          <h1>{hero.title ?? "Nutritious school meals, sourced from local farmers"}</h1>
          {hero.subtitle && <p>{hero.subtitle}</p>}
          <div className="row">
            <Link className="btn gold lg" href="/register">{hero.cta_label ?? "Register as a supplier"}</Link>
            <Link className="btn lg ghost" href="/opportunities">View open opportunities</Link>
          </div>
        </div>
        <HeroWaveBand />
      </section>

      {!!d?.live?.length && (<>
        <section className="wrap livestats" aria-label="LisheBora today">
          {d.live.map((s) => (
            <div key={s.key} className="ls"><span className="ls-mark" aria-hidden="true" />
              <b><CountUp to={s.value} /></b><span className="ls-label">{s.label}</span></div>))}
        </section>
        <p className="wrap small muted ls-note">Live figures from the platform, updated automatically.</p>
      </>)}
      {d?.stats && (
        <section className="wrap sec" style={{ paddingBottom: 0 }}>
          <h2 style={{ marginBottom: 14 }}>Programme at a glance</h2>
          <div className="stats flat">{d.stats.items.map((s) => <div key={s.label}><b>{s.value}</b><span>{s.label}</span></div>)}</div>
        </section>
      )}

      <section className="wrap sec">
        <div className="sechead"><span className="kicker">Who it is for</span><h2>Built for everyone in the school food chain</h2></div>
        <div className="grid g3">{AUDIENCES.map(([t, x, href, c, k]) => (
          <Link key={href} href={href} className="card aud" style={{ ["--ac" as string]: c }}>
            <span className="aud-dia" aria-hidden="true" /><span className="kicker">{k}</span><h3>{t}</h3><p className="small muted">{x}</p>
            <span className="more">Learn more →</span></Link>))}</div>
      </section>

      <section className="howband">
        <div className="wrap sec">
          <div className="sechead"><span className="kicker">How it works</span><h2>From the school plan to the supplier&apos;s payment</h2></div>
          <div className="grid g4 steps">{STEPS.map(([t, x], i) => (
            <div key={t} className="card howc"><span className="n">{i + 1}</span><h3>{t}</h3><p className="muted small">{x}</p></div>))}</div>
          <p style={{ marginTop: 16 }}><Link href="/how-it-works">Read the full process →</Link></p>
        </div>
      </section>

      {!!cats?.length && (
        <section className="wrap sec">
          <div className="sechead row"><div><span className="kicker">Food &amp; nutrition</span><h2>{cats.length} food categories, one balanced plate</h2>
            <p className="muted" style={{ margin: "6px 0 0" }}>Menus, demand and supplier prequalification all use the food categories of the programme&apos;s school survey.</p></div>
            <span className="spacer" /><Link href="/food-and-nutrition">See all foods →</Link></div>
          <div className="foodtiles">{cats.map((c) => { const [a, b] = colourFor(c.group); return (
            <Link key={c.key} href="/food-and-nutrition" className="ftile" style={{ ["--fa" as string]: a, ["--fb" as string]: b }}>
              <span className="fdia" aria-hidden="true" /><b>{c.label}</b>
              <span className="small muted">{c.commodities.slice(0, 3).map((x) => x.name).join(", ") || c.group}</span></Link>); })}</div>
        </section>
      )}

      {!!areas?.length && (
        <section className="areaband">
          <div className="wrap sec">
            <div className="sechead row"><div><span className="kicker">Where we work</span><h2>Pilot counties</h2></div><span className="spacer" /><Link href="/where-we-work">All schools →</Link></div>
            <div className="grid g3">{areas.map((a, i) => (
              <Link key={a.code} href="/where-we-work" className="card area" style={{ ["--ac" as string]: ACCENT[i % ACCENT.length] }}>
                <div className="row"><span className="adia" /><h3>{a.name}</h3></div>
                <div className="bignum">{a.schools}<span> schools</span></div>
                <p className="small muted">{a.sub_counties.map((s) => s.name).join(" · ")}</p></Link>))}</div>
          </div>
        </section>
      )}

      <section className="wrap sec">
        <div className="sechead"><span className="kicker">Why LisheBora</span><h2>Transparent, local and built for the field</h2></div>
        <div className="featgrid">{FEATURES.map(([t, x], i) => (
          <div key={t} className="feat"><span className="fdot" style={{ background: ACCENT[i % 4] }} aria-hidden="true" /><div><h3>{t}</h3><p className="small muted">{x}</p></div></div>))}</div>
      </section>

      <section className="wrap sec" style={{ paddingTop: 0 }}>
        <div className="row" style={{ marginBottom: 14 }}><h2>Open opportunities</h2><span className="spacer" /><Link href="/opportunities">See all →</Link></div>
        <NoticeTable rows={d?.notices ?? []} />
      </section>

      {!!d?.news.length && (
        <section className="wrap sec" style={{ paddingTop: 0 }}>
          <div className="row" style={{ marginBottom: 14 }}><h2>News &amp; updates</h2><span className="spacer" /><Link href="/news">All news →</Link></div>
          <div className="grid g3">{d.news.map((n) => <NewsCard key={n.slug} n={n} />)}</div>
        </section>
      )}

      {!!faq?.length && (
        <section className="wrap sec" style={{ paddingTop: 0 }}>
          <div className="grid g2" style={{ alignItems: "start" }}>
            <div><span className="kicker">Questions</span><h2>Frequently asked</h2>
              <p className="muted">Short answers to what suppliers and schools ask most often.</p><Link className="btn" href="/faq">All questions</Link></div>
            <div>{faq.slice(0, 4).map((f, i) => <details key={f.question} className="faq" open={i === 0}><summary>{f.question}</summary><p>{f.answer}</p></details>)}</div>
          </div>
        </section>
      )}

      <section className="wrap sec" style={{ paddingTop: 0 }}>
        <div className="aboutstrip">
          <div><span className="kicker">About AATF</span>
            <p>The African Agricultural Technology Foundation is an African-led, not-for-profit organisation, founded in 2003, working across
              Sub-Saharan Africa on agricultural technology transfer, seed systems and enabling policy environments.</p></div>
          <div className="row"><Link className="btn" href="/about">About LisheBora</Link><a className="btn" href="https://www.aatf-africa.org" target="_blank" rel="noreferrer">aatf-africa.org ↗</a></div>
        </div>
      </section>

      <section className="band">
        <div className="wrap row" style={{ justifyContent: "space-between" }}>
          <div><h2>Are you a farmer, cooperative or trader?</h2>
            <p style={{ margin: "6px 0 0", color: "#E4ECDC" }}>Register once and receive SMS alerts for new opportunities in your area. Assisted registration is available.</p></div>
          <Link className="btn gold lg" href="/register">Register now</Link>
        </div>
      </section>
      {!d && <div className="wrap alert warn">The platform API is not reachable. Start the backend (see README).</div>}
    </>
  );
}
