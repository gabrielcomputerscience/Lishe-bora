import { publicGet } from "@/lib/server";
export const metadata = { title: "FAQ" };
export default async function Faq() {
  const items = (await publicGet<{ question: string; answer: string }[]>("/faq")) ?? [];
  return (
    <section className="wrap sec narrow"><h1>Frequently asked questions</h1>
      {items.map((f, i) => <details key={f.question} className="faq" open={i === 0}><summary>{f.question}</summary><p>{f.answer}</p></details>)}
    </section>
  );
}
