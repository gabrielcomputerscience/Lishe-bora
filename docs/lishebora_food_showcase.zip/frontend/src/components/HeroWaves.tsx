/** Moving wave band along the bottom of banners, in the AATF brand colours (Brand Manual p.10), with a few fish that
 *  swim along the waves and leap out doing somersaults. Pure SVG + CSS; everything stops for reduced motion. */
function wave(width: number, height: number, base: number, amp: number, length: number) {
  let d = `M0 ${base}`;
  for (let x = 0; x < width * 2; x += length) d += ` Q ${x + length / 4} ${base - amp} ${x + length / 2} ${base} T ${x + length} ${base}`;
  return `${d} L ${width * 2} ${height} L 0 ${height} Z`;
}
const W = 1440, H = 120;
const BACK = [
  { color: "#75BA43", base: 40, amp: 14, len: 360, dur: 18, rev: false, op: 0.55 },   // leaf green
  { color: "#AB822D", base: 58, amp: 12, len: 300, dur: 13, rev: true, op: 0.7 },     // gold
  { color: "#F9B916", base: 76, amp: 10, len: 320, dur: 16, rev: false, op: 0.85 },   // amber
];
const FRONT = { color: "var(--bg)", base: 92, amp: 10, len: 280, dur: 11, rev: true, op: 1 };

// colour, size, swim seconds, delay, jump rhythm seconds, height in the water, direction
const FISH = [
  { body: "#507435", fin: "#F9B916", s: 40, swim: 26, delay: 0, jump: 5.5, b: 26, left: false },
  { body: "#F9B916", fin: "#AB822D", s: 30, swim: 34, delay: -12, jump: 7, b: 36, left: true },
  { body: "#912E91", fin: "#F9B916", s: 26, swim: 30, delay: -20, jump: 4.6, b: 22, left: false },
  { body: "#AB822D", fin: "#75BA43", s: 34, swim: 40, delay: -6, jump: 8.2, b: 40, left: true },
];

function Layer({ l }: { l: typeof FRONT }) {
  return <path d={wave(W, H, l.base, l.amp, l.len)} style={{ fill: l.color, animationDuration: `${l.dur}s` }} opacity={l.op}
               className={`dm-wave ${l.rev ? "rev" : ""}`} />;
}

function Fish({ body, fin, id }: { body: string; fin: string; id: string }) {
  return (
    <svg viewBox="0 0 64 40" className="fish-svg" aria-hidden="true">
      <defs>
        <radialGradient id={`fb${id}`} cx="62%" cy="32%" r="75%">
          <stop offset="0" stopColor="#fff" stopOpacity=".85" /><stop offset=".22" stopColor={body} /><stop offset="1" stopColor="#1E2A17" stopOpacity=".9" />
        </radialGradient>
        <linearGradient id={`ff${id}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={fin} /><stop offset="1" stopColor="#1E2A17" stopOpacity=".7" /></linearGradient>
        <linearGradient id={`fs${id}`} x1="0" y1="0" x2="0" y2="1"><stop offset=".55" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity=".35" /></linearGradient>
      </defs>
      <path className="fish-tail" d="M14 20 L0 6 Q4 20 0 34 Z" fill={`url(#ff${id})`} />
      <path d="M62 20 Q52 4 32 5 Q16 6 10 20 Q16 34 32 35 Q52 36 62 20 Z" fill={`url(#fb${id})`} />
      <path d="M62 20 Q52 4 32 5 Q16 6 10 20 Q16 34 32 35 Q52 36 62 20 Z" fill={`url(#fs${id})`} />
      <path d="M30 6 Q38 -2 46 8 Z" fill={`url(#ff${id})`} />
      <path className="fish-fin" d="M34 22 Q40 30 30 31 Z" fill={`url(#ff${id})`} opacity=".9" />
      {[0, 1, 2].map((k) => <path key={k} d={`M${22 + k * 8} 11 Q${18 + k * 8} 20 ${22 + k * 8} 29`} stroke="rgba(255,255,255,.35)" strokeWidth="1.4" fill="none" />)}
      <ellipse cx="42" cy="12" rx="10" ry="3" fill="#fff" opacity=".35" />
      <circle cx="50" cy="16" r="4.2" fill="#fff" /><circle cx="51" cy="16" r="2.2" fill="#1E2A17" /><circle cx="51.8" cy="15.2" r=".8" fill="#fff" />
      <path d="M58 22 Q55 24 53 23" stroke="#1E2A17" strokeWidth="1.5" fill="none" strokeLinecap="round" />
    </svg>
  );
}

export type ShowcaseScene = { label: string; items: string; images: { src: string; alt: string }[] };

/** Food showcase for the homepage: each food category rises out of the water, zooms towards the viewer in 3D, then
 *  sinks back and the next one follows. CSS only; the timing is set by --i (scene number) and --n (number of scenes). */
function Showcase({ scenes }: { scenes: ShowcaseScene[] }) {
  return (
    <div className="showcase" style={{ ["--n" as string]: scenes.length } as React.CSSProperties} aria-label="Foods on school menus">
      {scenes.map((sc, i) => (
        <div key={sc.label} className="sc-scene" style={{ ["--i" as string]: i } as React.CSSProperties}>
          <div className="sc-items">{sc.images.map((im, k) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={im.src} src={im.src} alt={im.alt} className="sc-img" loading="lazy"
                 style={{ ["--k" as string]: k, ["--m" as string]: sc.images.length } as React.CSSProperties} />))}</div>
          <div className="sc-label"><b>{sc.label}</b><span>{sc.items}</span></div>
          <span className="sc-splash" aria-hidden="true" />
        </div>))}
    </div>
  );
}

export function HeroWaveBand({ showcase }: { showcase?: ShowcaseScene[] } = {}) {
  return (
    <div className="hero-band" aria-hidden="true">
      <svg className="band-layer" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">{BACK.map((l, i) => <Layer key={i} l={l} />)}</svg>
      {!!showcase?.length && <Showcase scenes={showcase} />}
      <div className="fishes">
        {FISH.map((f, i) => (
          <div key={i} className={`fish-swim ${f.left ? "left" : ""}`}
               style={{ bottom: f.b, animationDuration: `${f.swim}s`, animationDelay: `${f.delay}s` } as React.CSSProperties}>
            <div className="fish-jump" style={{ width: f.s, height: f.s * 0.625, animationDuration: `${f.jump}s`, animationDelay: `${-i * 1.3}s` }}>
              <Fish body={f.body} fin={f.fin} id={String(i)} />
            </div>
          </div>))}
      </div>
      <svg className="band-layer" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none"><Layer l={FRONT} /></svg>
    </div>
  );
}
