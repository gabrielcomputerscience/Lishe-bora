from fastapi import APIRouter

from app.api.v1 import audit, auth, cms, iam, masterdata, procurement, public, suppliers

api_router = APIRouter(prefix="/api/v1")
for r in (auth.router, public.router, iam.router, masterdata.router, suppliers.router, procurement.router,
          cms.router, audit.router):
    api_router.include_router(r)
