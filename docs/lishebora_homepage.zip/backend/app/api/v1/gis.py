"""GIS (Phase 6): location coordinates, the programme map and suggested delivery routes."""
import uuid
from collections import defaultdict
from decimal import Decimal

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.database import get_db
from app.core.deps import Principal, descendants, ensure_in_scope, require, require_any, scope_any
from app.core.errors import AppError
from app.core.timeutil import as_utc
from app.models import (Complaint, ComplaintStatus, Dispatch, DispatchLine, DispatchStatus, Organization, OrgType,
                        ProofOfDelivery)
from app.services import audit, geo, stock

router = APIRouter(tags=["GIS"])
MAPPED = (OrgType.school, OrgType.aggregation_centre, OrgType.warehouse)


class GpsIn(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)
    accuracy_m: float | None = Field(default=None, ge=0)


@router.put("/fulfilment/locations/{oid}/gps")
def set_gps(oid: uuid.UUID, body: GpsIn, request: Request, p: Principal = Depends(require_any("md:edit", "inv:create", "agg:create", "log:approve")),
            db: Session = Depends(get_db)):
    """Field staff capture the coordinates of their own school, hub or store (e.g. from the phone's GPS)."""
    o = db.get(Organization, oid)
    if o is None or o.type not in MAPPED:
        raise AppError(404, "NOT_FOUND", "Location not found.")
    def ok(code: str) -> bool:
        if not p.can(code):
            return False
        sc = scope_any(db, p, code)
        return sc is None or o.id in sc
    if not any(ok(c) for c in ("md:edit", "inv:create", "agg:create", "log:approve")):
        raise AppError(403, "OUT_OF_SCOPE", "This location is outside your assigned area.")
    before = (o.meta or {}).get("gps")
    o.meta = {**(o.meta or {}), "gps": {"lat": round(body.lat, 6), "lng": round(body.lng, 6), "accuracy_m": body.accuracy_m}}
    audit.record(db, action="SET_GPS", entity="organization", entity_id=o.id, user=p.user, before={"gps": before}, after={"gps": o.meta["gps"]},
                 request=request)
    db.commit()
    return {"id": o.id, "name": o.name, "gps": o.meta["gps"]}


@router.get("/gis/map")
def programme_map(county_id: uuid.UUID | None = None, p: Principal = Depends(require_any("meal:view", "log:view", "rsk:view")),
                  db: Session = Depends(get_db)):
    allowed = scope_any(db, p, "meal:view", "log:view", "rsk:view")
    if county_id:
        if allowed is not None and county_id not in allowed:
            raise AppError(403, "OUT_OF_SCOPE", "This county is outside your assigned area.")
        allowed = descendants(db, [county_id])
    orgs = [o for o in db.scalars(select(Organization).where(Organization.type.in_(MAPPED), Organization.is_active)).all()
            if allowed is None or o.id in allowed]
    ids = {o.id for o in orgs}
    last_pod: dict = {}
    pods_n: dict = defaultdict(int)
    for x in db.scalars(select(ProofOfDelivery).where(ProofOfDelivery.school_id.in_(ids or {uuid.uuid4()}))).all():
        pods_n[x.school_id] += 1
        if x.school_id not in last_pod or as_utc(x.received_at) > as_utc(last_pod[x.school_id]):
            last_pod[x.school_id] = x.received_at
    complaints: dict = defaultdict(int)
    for c in db.scalars(select(Complaint).where(Complaint.school_id.in_(ids or {uuid.uuid4()}),
                                                Complaint.status.in_([ComplaintStatus.submitted, ComplaintStatus.investigating]))).all():
        complaints[c.school_id] += 1
    bal = stock.balances(db, ids)
    on_hand: dict = defaultdict(Decimal)
    alerts: dict = defaultdict(int)
    for r in bal:
        on_hand[r["location_id"]] += Decimal(r["on_hand"])
        alerts[r["location_id"]] += len(r["alerts"])
    points, missing = [], []
    for o in orgs:
        g = geo.gps(o)
        item = {"id": o.id, "name": o.name, "type": o.type.value, "code": o.code, "on_hand_kg": on_hand.get(o.id, Decimal(0)),
                "stock_alerts": alerts.get(o.id, 0)}
        if o.type == OrgType.school:
            item.update(deliveries=pods_n.get(o.id, 0), last_delivery=last_pod.get(o.id), open_complaints=complaints.get(o.id, 0))
        if g:
            points.append({**item, "lat": g[0], "lng": g[1]})
        else:
            missing.append(item)
    trips = []
    for d in db.scalars(select(Dispatch).options(selectinload(Dispatch.lines).selectinload(DispatchLine.school), selectinload(Dispatch.source))
                        .where(Dispatch.status.in_([DispatchStatus.dispatched, DispatchStatus.in_transit, DispatchStatus.delivered]))).all():
        if allowed is not None and d.source_location_id not in allowed and d.county_id not in allowed:
            continue
        fix = next((m for m in reversed(d.milestones or []) if m.get("lat") is not None), None)
        src = geo.gps(d.source)
        trips.append({"id": d.id, "reference": d.reference, "status": d.status.value, "vehicle": d.vehicle, "driver": d.driver_name,
                      "last_fix": {"lat": fix["lat"], "lng": fix["lng"], "at": fix["at"], "status": fix["status"]} if fix else None,
                      "source": {"lat": src[0], "lng": src[1]} if src else None,
                      "stops": [{"school": ln.school.name, **({"lat": geo.gps(ln.school)[0], "lng": geo.gps(ln.school)[1]} if geo.gps(ln.school) else {})}
                                for ln in {ln.school_id: ln for ln in d.lines}.values()]})
    return {"points": points, "without_coordinates": missing, "trips": trips,
            "counts": {"schools": sum(1 for o in orgs if o.type == OrgType.school),
                       "schools_served": sum(1 for o in orgs if o.type == OrgType.school and pods_n.get(o.id)),
                       "mapped": len(points), "unmapped": len(missing), "trips_on_road": len(trips)}}


def _route_for(db, d: Dispatch) -> dict:
    src = geo.gps(d.source)
    if not src:
        raise AppError(409, "NO_COORDINATES", f"Add GPS coordinates for {d.source.name} first.")
    schools = {ln.school_id: ln.school for ln in d.lines}
    r = geo.route(src, [(str(sid), geo.gps(s)) for sid, s in schools.items()])
    names = {str(k): v.name for k, v in schools.items()}
    r["stops"] = [{"school_id": k, "school": names[k], "km": next((x["km"] for x in r["legs"] if x["key"] == k), None),
                   **({"lat": geo.gps(schools[uuid.UUID(k)])[0], "lng": geo.gps(schools[uuid.UUID(k)])[1]} if geo.gps(schools[uuid.UUID(k)]) else {})}
                  for k in r["order"]]
    r["source"] = {"name": d.source.name, "lat": src[0], "lng": src[1]}
    return r


@router.get("/dispatches/{did}/route")
def suggest_route(did: uuid.UUID, p: Principal = Depends(require("log:view")), db: Session = Depends(get_db)):
    from app.api.v1.logistics import _load
    d = _load(db, did)
    ensure_in_scope(db, p, "log:view", d.source_location_id, d.county_id, *[ln.school_id for ln in d.lines])
    return {"suggested": _route_for(db, d), "saved": d.route}


@router.post("/dispatches/{did}/route")
def save_route(did: uuid.UUID, request: Request, p: Principal = Depends(require("log:create")), db: Session = Depends(get_db)):
    from app.api.v1.logistics import _load
    d = _load(db, did)
    ensure_in_scope(db, p, "log:create", d.source_location_id, d.county_id)
    if d.status not in (DispatchStatus.planned, DispatchStatus.dispatched):
        raise AppError(409, "INVALID_STATE", "The route can only be set before the trip is under way.")
    d.route = _route_for(db, d)
    audit.record(db, action="ROUTE", entity="dispatch", entity_id=d.id, user=p.user, after={"order": d.route["order"], "km": d.route["total_km"]},
                 request=request)
    db.commit()
    return {"saved": d.route}
