"""Seed roles, permissions, the first super-admin, pilot geography, commodities and starter website content.
Safe to run repeatedly (idempotent).   Usage:  python -m app.seed.run  [--demo]"""
import sys
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal
from app.core.security import hash_password
from app.core.timeutil import utcnow
from datetime import date
from decimal import Decimal

from app.models import (AcademicTerm, BudgetLine, FundingSource, Menu, MenuDay, MenuStatus, SystemSetting, Commodity, ContentStatus, EventStatus, FaqItem, NewsPost, Organization, OrgType, Page,
                        Permission, ProcurementEvent, ProcurementMethod, Resource, Role, RolePermission, SiteBlock,
                        User, UserRole, UserStatus)
from app.seed.matrix import ACTIONS, DOMAINS, ROLES, all_permission_codes, role_permission_codes

COMMODITIES = [
    ("MZE-G1", "Maize (grade 1)", "cereals", "kg", "Cereal", {"max_moisture_pct": 13.5}, 150),
    ("RICE", "Rice", "cereals", "kg", "Cereal", {}, 120),
    ("BEAN-RC", "Beans (rosecoco)", "pulses", "kg", "Legume", {"max_moisture_pct": 14}, 40),
    ("GGRAM", "Green grams", "pulses", "kg", "Legume", {}, 40),
    ("VEG-LEAFY", "Leafy vegetables", "vegetables", "kg", "Vegetable", {}, 60),
    ("VEG-CAB", "Cabbage", "vegetables", "kg", "Vegetable", {}, 60),
    ("FRUIT-BAN", "Bananas", "fruit", "kg", "Fruit", {}, 80),
    ("EGGS", "Eggs", "animal_source", "tray", "Animal-source", {}, None),
    ("MILK", "Milk", "animal_source", "litre", "Animal-source", {}, None),
    ("OIL-VEG", "Cooking oil", "oils", "litre", "Oil", {}, 10),
]


def upsert_permissions_and_roles(db: Session):
    perms = {p.code: p for p in db.scalars(select(Permission)).all()}
    for code in sorted(all_permission_codes()):
        if code not in perms:
            d, a = code.split(":")
            perms[code] = Permission(code=code, domain=d, action=a, description=f"{a} — {DOMAINS[d]}")
            db.add(perms[code])
    db.flush()
    for key, (name, tier, scope, mfa, _cells, _cms) in ROLES.items():
        role = db.scalar(select(Role).where(Role.key == key))
        if role is None:
            role = Role(key=key, name=name, tier=tier, default_scope=scope, requires_mfa=mfa)
            db.add(role)
            db.flush()
        role.name, role.tier, role.default_scope, role.requires_mfa = name, tier, scope, mfa
        want = role_permission_codes(key)
        have = {rp.permission.code: rp for rp in role.permissions}
        for code in want - have.keys():
            role.permissions.append(RolePermission(permission=perms[code]))
        for code in have.keys() - want:
            role.permissions.remove(have[code])
    db.flush()


def org(db, type_, code, name, parent=None, **meta):
    o = db.scalar(select(Organization).where(Organization.code == code))
    if o is None:
        o = Organization(type=type_, code=code, name=name, parent_id=parent.id if parent else None, meta=meta)
        db.add(o)
        db.flush()
    return o


def seed_geography(db):
    ke = org(db, OrgType.country, "KE", "Kenya")
    org(db, OrgType.programme, "STEP", "STEP School Feeding Project", ke)
    counties = {}
    # Pilot counties are not yet confirmed (SRS §14 Q1) — placeholders until inception decisions.
    for i, letter in enumerate("AB", 1):
        c = org(db, OrgType.county, f"PILOT-{letter}", f"Pilot County {letter}", ke)
        sc = org(db, OrgType.sub_county, f"PILOT-{letter}-SC1", f"Pilot County {letter} · Sub-county 1", c)
        cl = org(db, OrgType.school_cluster, f"PILOT-{letter}-CL1", f"Cluster {i}", sc)
        org(db, OrgType.school, f"PILOT-{letter}-SCH001", f"Demo Primary School {i:03d}", cl, enrolment=None)
        if letter == "A":
            org(db, OrgType.school, "PILOT-A-SCH002", "Demo Primary School 003", cl)
        counties[letter] = c
    return counties


def seed_admin(db):
    u = db.scalar(select(User).where(User.email == settings.seed_admin_email.lower()))
    if u is None:
        u = User(full_name="Super Administrator", email=settings.seed_admin_email.lower(),
                 password_hash=hash_password(settings.seed_admin_password), status=UserStatus.active)
        db.add(u)
        db.flush()
        role = db.scalar(select(Role).where(Role.key == "super_admin"))
        db.add(UserRole(user_id=u.id, role_id=role.id, org_id=None))
        print(f"Created super admin: {settings.seed_admin_email}  (password from SEED_ADMIN_PASSWORD — change it!)")
    return u


def seed_commodities(db):
    for code, name, cat, unit, fg, spec, portion in COMMODITIES:
        if db.scalar(select(Commodity).where(Commodity.code == code)) is None:
            db.add(Commodity(code=code, name=name, category=cat, unit=unit, food_group=fg, quality_spec=spec,
                             default_portion_g=portion))


def seed_cms(db, admin):
    now = utcnow()
    blocks = {
        "hero": {"eyebrow": "STEP School Feeding Project",
                 "title": "Nutritious school meals, sourced from local farmers",
                 "subtitle": "LisheBora connects schools with qualified local producers, cooperatives and aggregators. "
                             "Procurement is open, fair and traceable, and suppliers are paid faster.",
                 "cta_label": "Register as a supplier"},
        # Figures must come from signed-off MEAL data — placeholders until then.
        "stats": {"show": False, "items": [{"value": "[x]", "label": "schools in the pilot"},
                                           {"value": "[x]", "label": "registered suppliers"},
                                           {"value": "[x]%", "label": "of food sourced locally"},
                                           {"value": "[x]%", "label": "of contract value to women-, youth- and PWD-led suppliers"}]},
    }
    for key, data in blocks.items():
        if db.scalar(select(SiteBlock).where(SiteBlock.key == key)) is None:
            db.add(SiteBlock(key=key, data=data, published_data=data, status=ContentStatus.published,
                             published_at=now, published_by=admin.id))
    pages = {
        "about": ("About LisheBora", "LisheBora is being developed under the STEP School Feeding Project to strengthen "
                  "links between schools, local producers, aggregators and other suppliers.\n\n"
                  "*[Programme description to be supplied and approved by the programme team.]*"),
        "how-it-works": ("How it works", "## For suppliers\nRegister → get prequalified → receive alerts → submit sealed bids → "
                         "deliver → invoice and track payment.\n\n## For schools\nEnter enrolment, feeding days and menus → "
                         "confirm deliveries on your phone.\n\n## For counties\nApprove plans and budgets → run sourcing → "
                         "monitor delivery, payments and inclusion."),
        "privacy": ("Privacy notice", "*[Privacy notice aligned with the Data Protection Act, 2019 — to be supplied by legal.]*"),
        "terms": ("Terms of use", "*[Terms of use — to be supplied by legal.]*"),
    }
    for slug, (title, body) in pages.items():
        if db.scalar(select(Page).where(Page.slug == slug)) is None:
            db.add(Page(slug=slug, title=title, body=body, status=ContentStatus.published, published_at=now,
                        published_by=admin.id))
    if db.scalar(select(NewsPost.id).limit(1)) is None:
        db.add(NewsPost(slug="supplier-registration-opens", title="Supplier registration opens for pilot counties",
                        category="Announcement",
                        summary="Farmers, cooperatives, aggregators and traders in the pilot counties can now register "
                                "and apply for prequalification.",
                        body="*[Full article to be written by the content editor.]*",
                        status=ContentStatus.published, published_at=now, published_by=admin.id))
    if db.scalar(select(FaqItem.id).limit(1)) is None:
        for i, (q, a) in enumerate([
            ("Who can register as a supplier?", "Individual farmers, farmer groups and cooperatives, aggregators, traders, "
                                                "processors and MSMEs operating in the pilot counties."),
            ("I don't have a smartphone. Can I still take part?", "Yes. Assisted registration is available through county "
                                                                  "officers, aggregators and the helpdesk. Alerts are also sent by SMS."),
            ("How are winning bids chosen?", "Against the criteria published in each notice, such as price, quality, "
                                             "capacity, local sourcing and inclusion."),
            ("How long do payments take?", "Payment starts once goods are accepted and a valid invoice is submitted. "
                                           "You can track status in your portal."),
        ]):
            db.add(FaqItem(question=q, answer=a, sort_order=i))
    if db.scalar(select(Resource.id).limit(1)) is None:
        db.add(Resource(title="Supplier registration checklist", description="Documents you need to register",
                        is_published=True))


def seed_demo(db, counties):
    """Optional demo notices so the public site isn't empty during development."""
    now = utcnow()
    for ref, title, days, cats in [("RFQ-2026-A-0042", "Maize grade 1: Cluster 1 (demo)", 5, ["cereals"]),
                                   ("RFQ-2026-A-0043", "Beans & pulses: Term 3 (demo)", 12, ["pulses"])]:
        if db.scalar(select(ProcurementEvent).where(ProcurementEvent.reference == ref)) is None:
            db.add(ProcurementEvent(reference=ref, title=title, method=ProcurementMethod.rfq, county_id=counties["A"].id,
                                    eligibility="Prequalified: " + ", ".join(cats), categories=cats,
                                    closes_at=now + timedelta(days=days), status=EventStatus.open))


def seed_terms_and_rules(db):
    # Kenyan school calendar dates are placeholders — confirm with the programme (SRS §14).
    for y, n, s_, e_, days in [(2026, 1, date(2026, 1, 5), date(2026, 4, 2), 58), (2026, 2, date(2026, 4, 27), date(2026, 7, 31), 62),
                               (2026, 3, date(2026, 8, 24), date(2026, 10, 30), 45)]:
        if db.scalar(select(AcademicTerm).where(AcademicTerm.year == y, AcademicTerm.term_no == n)) is None:
            db.add(AcademicTerm(year=y, term_no=n, name=f"Term {n} {y}", starts_on=s_, ends_on=e_, feeding_days=days))
    if db.scalar(select(SystemSetting).where(SystemSetting.key == "nutrition.rules")) is None:
        from app.services.demand import DEFAULT_RULES
        db.add(SystemSetting(key="nutrition.rules", value=DEFAULT_RULES,
                             description="Menu diversity and demand validation rules — to be validated by nutrition authorities"))


DEMO_USERS = [
    ("meals.officer@demo.lishebora", "School Meals Officer (demo)", "school_meals_officer", "PILOT-A-SCH001"),
    ("school.admin@demo.lishebora", "School Administrator (demo)", "school_admin", "PILOT-A-SCH001"),
    ("nutrition@demo.lishebora", "Nutrition Officer (demo)", "nutrition_officer", "PILOT-A"),
    ("procurement@demo.lishebora", "County Procurement Officer (demo)", "county_procurement_officer", "PILOT-A"),
    ("finance@demo.lishebora", "County Finance Officer (demo)", "county_finance_officer", "PILOT-A"),
    ("county.admin@demo.lishebora", "County Administrator (demo)", "county_admin", "PILOT-A"),
    ("approver@demo.lishebora", "Approving Officer (demo)", "approving_officer", "PILOT-A"),
    ("evaluator1@demo.lishebora", "Evaluator One (demo)", "evaluation_committee_member", "PILOT-A"),
    ("evaluator2@demo.lishebora", "Evaluator Two (demo)", "evaluation_committee_member", "PILOT-A"),
    ("editor@demo.lishebora", "Content Editor (demo)", "content_editor", None),
    ("auditor@demo.lishebora", "Auditor (demo)", "auditor", None),
]


def seed_demo_planning(db, counties):
    """Illustrative data for development ONLY — prices and budgets are not programme figures."""
    prices = {"MZE-G1": 55, "RICE": 160, "BEAN-RC": 130, "GGRAM": 150, "VEG-LEAFY": 60, "VEG-CAB": 40,
              "FRUIT-BAN": 70, "OIL-VEG": 300}
    for code, pr in prices.items():
        c = db.scalar(select(Commodity).where(Commodity.code == code))
        if c and c.reference_price is None:
            c.reference_price = pr
    if db.scalar(select(Menu).where(Menu.name == "Standard 5-day menu (demo)")) is None:
        m = Menu(name="Standard 5-day menu (demo)", description="Illustrative only — portions to be set by nutrition officers.",
                 status=MenuStatus.approved, approved_at=utcnow())
        for i, (lbl, dish, comps) in enumerate([
            ("Mon", "Githeri with cabbage", [("MZE-G1", 150), ("BEAN-RC", 40), ("VEG-CAB", 60), ("OIL-VEG", 10)]),
            ("Tue", "Rice and beans with greens", [("RICE", 120), ("BEAN-RC", 40), ("VEG-LEAFY", 60), ("OIL-VEG", 10)]),
            ("Wed", "Githeri with greens", [("MZE-G1", 150), ("BEAN-RC", 40), ("VEG-LEAFY", 60), ("OIL-VEG", 10)]),
            ("Thu", "Ugali, green grams and greens", [("MZE-G1", 150), ("GGRAM", 40), ("VEG-LEAFY", 60), ("OIL-VEG", 10)]),
            ("Fri", "Rice, beans and banana", [("RICE", 120), ("BEAN-RC", 40), ("FRUIT-BAN", 80), ("OIL-VEG", 10)])], 1):
            m.days.append(MenuDay(day_index=i, label=lbl, dish=dish, components=[{"commodity": c, "portion_g": g} for c, g in comps]))
        db.add(m)
    fs = db.scalar(select(FundingSource).where(FundingSource.code == "DEMO-GRANT"))
    if fs is None:
        fs = FundingSource(code="DEMO-GRANT", name="Programme grant (demo)", kind="grant")
        db.add(fs)
        db.flush()
    t3 = db.scalar(select(AcademicTerm).where(AcademicTerm.year == 2026, AcademicTerm.term_no == 3))
    if db.scalar(select(BudgetLine).where(BudgetLine.code == "DEMO-A-T3")) is None:
        db.add(BudgetLine(code="DEMO-A-T3", name="Pilot County A · school feeding · Term 3 2026 (demo)", funding_source_id=fs.id,
                          org_id=counties["A"].id, term_id=t3.id, period_start=t3.starts_on, period_end=t3.ends_on,
                          approved_amount=Decimal("2500000")))
    created = []
    for email, name, role_key, org_code in DEMO_USERS:
        if db.scalar(select(User).where(User.email == email)) is None:
            u = User(full_name=name, email=email, password_hash=hash_password(settings.seed_demo_password), status=UserStatus.active)
            db.add(u)
            db.flush()
            oid = db.scalar(select(Organization.id).where(Organization.code == org_code)) if org_code else None
            db.add(UserRole(user_id=u.id, role_id=db.scalar(select(Role.id).where(Role.key == role_key)), org_id=oid))
            created.append(email)
    created += seed_demo_suppliers(db, counties)
    created += seed_demo_fulfilment(db, counties)
    if created:
        print("Demo users (password from SEED_DEMO_PASSWORD):\n  " + "\n  ".join(created))


def seed_demo_suppliers(db, counties):
    """Two prequalified demo suppliers with verified placeholder documents, so bidding can be tried end to end."""
    import hashlib
    from pathlib import Path
    from app.models import DocumentStatus, Supplier, SupplierDocument, SupplierStatus, SupplierType
    pdf = b"%PDF-1.4\n% LisheBora demo placeholder document\n"
    out = []
    for email, phone, name, stype, lead in [
        ("supplier1@demo.lishebora", "+254700000101", "Umoja Farmers Cooperative (demo)", SupplierType.cooperative, "women"),
        ("supplier2@demo.lishebora", "+254700000102", "Tumaini Grain Traders (demo)", SupplierType.trader, "none"),
    ]:
        if db.scalar(select(User).where(User.email == email)):
            continue
        o = Organization(type=OrgType.supplier, name=name, code=f"SUP-DEMO-{phone[-3:]}", parent_id=counties["A"].id)
        db.add(o)
        db.flush()
        u = User(full_name=name.replace(" (demo)", " contact"), email=email, phone=phone,
                 password_hash=hash_password(settings.seed_demo_password), status=UserStatus.active)
        db.add(u)
        db.flush()
        role = "farmer_group" if stype == SupplierType.cooperative else "supplier"
        db.add(UserRole(user_id=u.id, role_id=db.scalar(select(Role.id).where(Role.key == role)), org_id=o.id))
        sup = Supplier(organization_id=o.id, county_id=counties["A"].id, supplier_type=stype, legal_name=name, phone=phone,
                       email=email, commodities=["MZE-G1", "RICE", "BEAN-RC", "GGRAM", "VEG-LEAFY", "VEG-CAB", "FRUIT-BAN", "OIL-VEG"],
                       approved_categories=["cereals", "pulses", "vegetables", "fruit", "oils"],
                       inclusion_claim={"leadership": lead}, inclusion_consent=True, inclusion_verified=lead != "none",
                       status=SupplierStatus.prequalified, created_by=u.id)
        db.add(sup)
        db.flush()
        for t in ("registration", "bank"):
            key = f"suppliers/{sup.id}/demo-{t}.pdf"
            path = Path(settings.storage_dir) / key
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(pdf)
            db.add(SupplierDocument(supplier_id=sup.id, doc_type=t, file_key=key, file_name=f"demo-{t}.pdf",
                                    content_type="application/pdf", size_bytes=len(pdf), sha256=hashlib.sha256(pdf).hexdigest(),
                                    status=DocumentStatus.verified))
        out.append(email)
    return out


DEMO_P4_USERS = [
    ("aggregator@demo.lishebora", "+254700000201", "Hub Aggregator (demo)", "aggregator", "SUP-DEMO-101"),
    ("inspector@demo.lishebora", "+254700000202", "Quality Inspector (demo)", "quality_inspector", "PILOT-A"),
    ("warehouse@demo.lishebora", "+254700000203", "Warehouse Officer (demo)", "warehouse_officer", "WH-DEMO-A1"),
    ("warehouse.supervisor@demo.lishebora", "+254700000204", "Warehouse Supervisor (demo)", "warehouse_officer", "PILOT-A"),
    ("logistics@demo.lishebora", "+254700000205", "Logistics Officer (demo)", "logistics_officer", "PILOT-A"),
    ("driver@demo.lishebora", "+254700000206", "Peter Driver (demo)", "driver", "PILOT-A"),
    ("school2.admin@demo.lishebora", "+254700000207", "School 003 Administrator (demo)", "school_admin", "PILOT-A-SCH002"),
    ("risk@demo.lishebora", "+254700000208", "Risk & Compliance Officer (demo)", "risk_compliance_officer", "PILOT-A"),
]


def seed_demo_fulfilment(db, counties):
    """Phase 4 demo: an aggregation hub under the demo cooperative, a county store, field users,
    and one acknowledged purchase order (maize + beans for two schools) ready to be fulfilled. Illustrative only."""
    from app.models import (Contract, ContractKind, ContractLine, EventStatus, POLine, POStatus, ProcurementLot,
                            PurchaseOrder, Supplier)
    sup_org = db.scalar(select(Organization).where(Organization.code == "SUP-DEMO-101"))
    if sup_org is None:
        return []
    org(db, OrgType.aggregation_centre, "HUB-DEMO-101", "Umoja Aggregation Hub (demo)", sup_org)
    org(db, OrgType.warehouse, "WH-DEMO-A1", "Pilot County A Food Store (demo)", counties["A"])
    out = []
    for email, phone, name, role_key, org_code in DEMO_P4_USERS:
        if db.scalar(select(User).where(User.email == email)):
            continue
        u = User(full_name=name, email=email, phone=phone, password_hash=hash_password(settings.seed_demo_password),
                 status=UserStatus.active)
        db.add(u)
        db.flush()
        db.add(UserRole(user_id=u.id, role_id=db.scalar(select(Role.id).where(Role.key == role_key)),
                        org_id=db.scalar(select(Organization.id).where(Organization.code == org_code))))
        out.append(email)
    if db.scalar(select(PurchaseOrder).where(PurchaseOrder.reference == "PO-DEMO-0001")) is None:
        sup = db.scalar(select(Supplier).where(Supplier.organization_id == sup_org.id))
        s1 = db.scalar(select(Organization).where(Organization.code == "PILOT-A-SCH001"))
        s2 = db.scalar(select(Organization).where(Organization.code == "PILOT-A-SCH002"))
        now = utcnow()
        ev = ProcurementEvent(reference="RFQ-DEMO-P4", title="Demo award for fulfilment testing", method=ProcurementMethod.rfq,
                              county_id=counties["A"].id, closes_at=now - timedelta(days=10), status=EventStatus.awarded,
                              is_public=False, awarded_to=sup.legal_name, awarded_at=now - timedelta(days=5))
        spec = [("MZE-G1", "Maize (grade 1)", "cereals", 700, 500, Decimal("55")), ("BEAN-RC", "Beans (rosecoco)", "pulses", 180, 120, Decimal("130"))]
        for i, (code, nm, cat, q1, q2, _pr) in enumerate(spec, 1):
            ev.lots.append(ProcurementLot(lot_no=i, name=nm, commodity_code=code, category=cat, quantity=Decimal(q1 + q2),
                                          schools=[{"school_id": str(s1.id), "name": s1.name, "qty": str(q1)},
                                                   {"school_id": str(s2.id), "name": s2.name, "qty": str(q2)}]))
        db.add(ev)
        db.flush()
        total = sum(((Decimal(q1 + q2) * pr) for _, _, _, q1, q2, pr in spec), Decimal(0))
        con = Contract(reference="CON-DEMO-0001", event_id=ev.id, supplier_id=sup.id, county_id=counties["A"].id,
                       kind=ContractKind.purchase, value=total, starts_on=date.today() - timedelta(days=5),
                       ends_on=date.today() + timedelta(days=90), terms="Demo contract (illustrative).")
        po = PurchaseOrder(reference="PO-DEMO-0001", supplier_id=sup.id, county_id=counties["A"].id, status=POStatus.acknowledged,
                           total=total, delivery_window="Within 2 weeks (demo)", issued_at=now - timedelta(days=4),
                           acknowledged_at=now - timedelta(days=3))
        for lot, (code, _, _, q1, q2, pr) in zip(ev.lots, spec):
            cl = ContractLine(lot_id=lot.id, commodity_code=code, quantity=lot.quantity, unit_price=pr, quantity_ordered=lot.quantity)
            con.lines.append(cl)
        db.add(con)
        db.flush()
        po.contract_id = con.id
        for lot, cl, (code, _, _, q1, q2, pr) in zip(ev.lots, con.lines, spec):
            po.lines.append(POLine(contract_line_id=cl.id, commodity_code=code, quantity=lot.quantity, unit_price=pr, schools=lot.schools))
        db.add(po)
        db.flush()
    return out


def main(demo: bool = False):
    db = SessionLocal()
    try:
        upsert_permissions_and_roles(db)
        counties = seed_geography(db)
        admin = seed_admin(db)
        seed_commodities(db)
        seed_cms(db, admin)
        seed_terms_and_rules(db)
        db.flush()
        if demo:
            seed_demo_planning(db, counties)
        db.commit()
        print(f"Seed complete: {len(ROLES)} roles, {len(all_permission_codes())} permissions.")
    finally:
        db.close()


if __name__ == "__main__":
    main(demo="--demo" in sys.argv)
