"use client";
import { useState } from "react";
import { Field, ErrorBox } from "@/components/ui";
import { ApiError, post } from "@/lib/api";

export default function Contact() {
  const [f, setF] = useState({ name: "", contact: "", topic: "general", message: "", website: "" });
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState<unknown>(null);
  const [fe, setFe] = useState<Record<string, string>>({});
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(null); setFe({});
    try { await post("/public/contact", f); setSent(true); }
    catch (x) { setErr(x); if (x instanceof ApiError) setFe(x.fieldErrors()); }
  }
  return (
    <section className="wrap sec narrow">
      <h1>Contact &amp; feedback</h1>
      <p className="lead">Questions, feedback or a grievance? Send us a message. Registered users can also raise a case from their portal and track it.</p>
      {sent ? <div className="alert info">Thank you. We have received your message.</div> : (
        <form className="card" onSubmit={submit} noValidate>
          <div className="grid g2">
            <Field label="Name" id="n" error={fe.name}><input id="n" value={f.name} onChange={set("name")} required /></Field>
            <Field label="Phone or email" id="c" error={fe.contact}><input id="c" value={f.contact} onChange={set("contact")} required /></Field>
          </div>
          <Field label="Topic" id="t"><select id="t" value={f.topic} onChange={set("topic")}>
            <option value="general">General question</option><option value="registration">Registration help</option>
            <option value="grievance">Complaint / grievance</option><option value="media">Media</option></select></Field>
          <Field label="Message" id="m" error={fe.message}><textarea id="m" rows={5} value={f.message} onChange={set("message")} required /></Field>
          <input className="sr-only" tabIndex={-1} autoComplete="off" aria-hidden="true" value={f.website} onChange={set("website")} />
          <ErrorBox error={err} />
          <button className="btn primary" type="submit">Send message</button>
        </form>)}
    </section>
  );
}
