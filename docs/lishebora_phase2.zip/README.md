# LisheBora e-Sourcing Platform

School food procurement and supply-chain platform for the **STEP School Feeding Project**.
Built from *SRS Consolidated Draft v0.3*, with colours and type from the AATF Brand Manual.

```
LisheeBora/
├── backend/     FastAPI · SQLAlchemy · Alembic · PostgreSQL/SQLite   → http://localhost:8000
├── frontend/    Next.js 15 · React 19 · TypeScript                   → http://localhost:3000
├── scripts/     Windows helpers: setup, start, reset
├── docs/        Specification, review, prototype and brand manual
└── docker-compose.yml   optional PostgreSQL + PostGIS
```

The browser only talks to the **frontend**. Next.js forwards `/api/*` to the backend, so auth cookies stay first-party and httpOnly.

## Quick start (Windows + PyCharm)

**You need:** Python 3.11 or newer (your `.venv` is 3.14), and Node.js 20 or newer from https://nodejs.org.

1. Open a terminal in PyCharm at the project root and run:
   ```bat
   scripts\setup.bat
   ```
   This installs the packages, creates the database, and seeds roles, the first admin, pilot geography, commodities and starter website content.
2. Start both servers. There are two ways:
   - **PyCharm:** use the ready-made run configurations (top-right dropdown): **Backend API (uvicorn)** and **Frontend (next dev)**, or **Full stack** to start both together.
   - **Terminal:** run `scripts\start-backend.bat` and `scripts\start-frontend.bat` in two terminals.
3. Open **http://localhost:3000**.

> PyCharm **Community** can't run npm configurations. Use `scripts\start-frontend.bat`, or run `npm run dev` in `frontend/`.

### First sign-in

| | |
|---|---|
| URL | http://localhost:3000/sign-in |
| Email | `admin@lishebora.local` |
| Password | `ChangeMe!2026` (set in `backend/.env` → `SEED_ADMIN_PASSWORD`; **change it**) |

Admin roles need two-step verification. In development there is no SMS gateway, so **the code is shown on screen** and printed in the backend console. `DEBUG=true` turns this on; never enable it in production.

## Demo users (development)

`python -m app.seed.run --demo` creates one user per key role. The password is `SEED_DEMO_PASSWORD` in `backend/.env` (default `Demo!2026pass`).

| Email | Role | Scope |
|---|---|---|
| meals.officer@demo.lishebora | School Meals Officer | Demo Primary School 001 |
| school.admin@demo.lishebora | School Administrator | Demo Primary School 001 |
| nutrition@demo.lishebora | Nutrition Officer | Pilot County A |
| procurement@demo.lishebora | County Procurement Officer | Pilot County A |
| finance@demo.lishebora | County Finance Officer | Pilot County A |
| county.admin@demo.lishebora | County Administrator | Pilot County A |
| editor@demo.lishebora | Content Editor | website |
| auditor@demo.lishebora | Auditor | national, read-only |

**Try the Phase 2 flow:**

1. The meals officer creates a Term 3 demand and submits it.
2. The school admin approves it from *My approvals*.
3. The procurement officer consolidates it into a plan and submits it.
4. Finance confirms the budget.
5. The county admin approves the plan, and the budget shows the commitment.

## Phase 2: demand, nutrition & budget (in this build)

| Area | Included |
|---|---|
| Terms & menus | Academic terms with feeding days; menu cycles with grams per learner per meal; food-group diversity check; nutrition validation workflow |
| School demand | Learners × attendance × feeding days × menu portions × (1 + wastage) − stock; quantity overrides with reasons; validation (blocking errors and warnings); approval: validate → approve |
| Consolidation | Approved demand is grouped into lots (cluster × category, or county-wide) → procurement plan, with reference prices for estimates |
| Budget | Budget lines per funding source, county and period; approved / committed / invoiced / paid / available; alerts at a threshold and on over-commitment |
| Controls | A plan can't be submitted without a budget line and prices; submission is blocked if the budget is insufficient, unless an approved **budget exception** exists; funds are held (committed) when the county approves |
| Approval engine | Reusable multi-stage workflows with permission + scope checks, *no self-approval*, one person per stage, SLA due dates, return/reject with a mandatory reason, full history, and **My approvals** inbox |

## What's in this build: Phase 1, the platform foundation

| Area | Included |
|---|---|
| Public website | Home, About, How it works, Opportunities (open notices and awards), News, Resources, FAQ, Contact, privacy/terms. **All content is admin-managed.** |
| Accounts | Supplier self-registration (farmer, cooperative, aggregator, trader) with phone OTP; sign-in by password or SMS code; two-step verification for privileged roles; lockout after 5 failed tries; password reset; session list and remote sign-out |
| Roles & scope | All 24 roles and 111 permissions from the SRS matrix; **User → Role → Data scope → Permission** enforced in the API; segregation-of-duties checks (conflicting roles, no self-assignment) |
| Supplier registry | Documents (PDF/JPG/PNG, versioned, checksummed, type-sniffed); verification by county officers; inclusion claims verified before they count; prequalification state machine with separate verify and approve permissions |
| Website CMS | Hero, statistics, news, pages and FAQ; the Content Editor drafts and submits, an approver publishes; version history |
| Sourcing (slice) | Create and publish sourcing notices to the website. Bids and evaluation come in Phase 3. |
| Audit trail | Append-only log of every material action, readable only by Auditor/Admin roles |
| API | Versioned REST `/api/v1`, OpenAPI docs at http://localhost:8000/api/docs, standard error envelope with correlation IDs |

**Next phases** follow SRS §12: 3 · e-procurement (RFQs, sealed bids, evaluation, awards, POs, contracts) → 4 · fulfilment (offline e-POD) → 5 · finance & performance.

## Common tasks

| Task | Command (from `backend/`, with the venv active) |
|---|---|
| Run tests | `python -m pytest -q` (23 tests) |
| New migration after changing models | `python -m alembic revision --autogenerate -m "describe change"` then `python -m alembic upgrade head` |
| Reset the local database | `scripts\reset-db.bat` |
| Switch to PostgreSQL | `docker compose up -d db`, then set `DATABASE_URL` in `backend/.env` (see `.env.example`) and run the migrations |
| Frontend type-check / build | `npm run typecheck` / `npm run build` (in `frontend/`) |

## Before production (not done yet)

- An SMS gateway and email provider adapter in `backend/app/services/notify.py`, replacing the console sender.
- `JWT_SECRET`, `COOKIE_SECURE=true`, `DEBUG=false`, `APP_ENV=production`; PostgreSQL; S3-compatible storage in `services/storage.py`; a malware-scan hook.
- Rate limiting at the gateway, plus a CSRF token for cookie-authenticated form posts (SameSite=Lax is the current mitigation).
- Confirmed pilot counties, thresholds and legal texts (SRS §14 questions). The seed uses **placeholders**: "Pilot County A/B", `[x]` statistics.

## Changes from SRS v0.3 made during the build

1. **New `cms` permission domain** and a **Content Editor** role for the admin-managed website.
2. **"View" is implied** by any other permission on a domain. In the matrix, admins had create/edit on users but no view. Records stay limited to the role's data scope.
3. Supplier registration reuses the **Supplier / Farmer Group / Aggregator** roles, scoped to the supplier's own organisation.
4. **Budget is held when a plan is approved**, not only when a PO is raised, so two plans can't spend the same money. Phase 3 turns this hold into the PO commitment.
5. Menus created by county-scoped users belong to their county. Programme-wide templates need a national-scope user.
6. School demand allows the same person (e.g. a head teacher) to validate and then approve, because small schools may have one administrator. The person who *submitted* it can never approve it.
