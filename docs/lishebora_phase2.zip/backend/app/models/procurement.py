"""Phase-1 slice of procurement: sourcing events (needed for public opportunity notices).
Bids, evaluation and awards are built in Phase 3."""
import enum
import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import JSON, Boolean, DateTime, Enum, ForeignKey, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import IdMixin, TimestampMixin


class ProcurementMethod(str, enum.Enum):
    rfq = "rfq"
    competitive = "competitive"
    framework = "framework"
    call_off = "call_off"
    direct = "direct"


class EventStatus(str, enum.Enum):
    draft = "draft"
    published = "published"
    open = "open"
    closed = "closed"
    under_evaluation = "under_evaluation"
    approved = "approved"
    awarded = "awarded"
    cancelled = "cancelled"


class ProcurementEvent(IdMixin, TimestampMixin, Base):
    __tablename__ = "procurement_events"

    reference: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(200))
    method: Mapped[ProcurementMethod] = mapped_column(Enum(ProcurementMethod, native_enum=False, length=16))
    county_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("organizations.id"), nullable=True)
    description: Mapped[str] = mapped_column(Text, default="")
    eligibility: Mapped[str] = mapped_column(String(200), default="")
    categories: Mapped[list] = mapped_column(JSON, default=list)
    estimated_value: Mapped[Decimal | None] = mapped_column(Numeric(14, 2), nullable=True)
    opens_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    closes_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[EventStatus] = mapped_column(Enum(EventStatus, native_enum=False, length=20), default=EventStatus.draft)
    is_public: Mapped[bool] = mapped_column(Boolean, default=True)
    awarded_to: Mapped[str] = mapped_column(String(200), default="")
    awarded_value: Mapped[Decimal | None] = mapped_column(Numeric(14, 2), nullable=True)
    awarded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    county = relationship("Organization")
