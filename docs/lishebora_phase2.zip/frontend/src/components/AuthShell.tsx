import Link from "next/link";
import { Logo, Vein } from "./Brand";

export function AuthShell({ children, aside }: { children: React.ReactNode; aside: React.ReactNode }) {
  return (
    <div className="auth">
      <div className="l">
        <Link href="/" aria-label="Back to website"><Logo tagline /></Link>
        <div className="form">{children}</div>
        <div className="small muted"><Link href="/">← Back to website</Link> · <Link href="/p/privacy">Privacy</Link></div>
      </div>
      <div className="r"><Vein /><div className="panel">{aside}</div></div>
    </div>
  );
}

export const SignInAside = (
  <><h2>Welcome to LisheBora</h2>
    <ul className="ticks"><li>Suppliers: find opportunities, bid and track payments</li><li>Schools: plan demand and confirm deliveries</li><li>Counties: approve, monitor and report</li></ul>
    <div className="alert info">Staff and school accounts are created by invitation. Suppliers can self-register.</div></>
);
export const RegisterAside = (
  <><h2>Need help registering?</h2>
    <p className="muted small">Assisted registration is available through county officers, aggregators and the helpdesk, and a group can register all its members in one go.</p>
    <ul className="ticks"><li>Takes about 10 minutes</li><li>SMS alerts for new opportunities</li><li>Upload documents now or later</li></ul>
    <div className="alert info">Helpdesk: [phone / SMS short code]</div></>
);
