"""File storage. Local disk in development; swap for S3-compatible storage in production (SRS §9.4).
Files are stored by opaque key, never by user-supplied path."""
import hashlib
import uuid
from pathlib import Path

from fastapi import UploadFile

from app.core.config import settings
from app.core.errors import AppError

MAGIC = {b"%PDF": "application/pdf", b"\xff\xd8\xff": "image/jpeg", b"\x89PNG": "image/png"}


def _sniff(head: bytes) -> str | None:
    for sig, ct in MAGIC.items():
        if head.startswith(sig):
            return ct
    return None


async def save_upload(file: UploadFile, folder: str) -> dict:
    allowed = {t.strip() for t in settings.allowed_upload_types.split(",")}
    data = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise AppError(413, "FILE_TOO_LARGE", f"Files must be under {settings.max_upload_mb} MB.")
    if not data:
        raise AppError(400, "FILE_EMPTY", "The file is empty.")
    ct = _sniff(data[:8])
    if ct is None or ct not in allowed:
        raise AppError(415, "FILE_TYPE", "Upload a PDF, JPG or PNG file.")
    # TODO(production): malware scan hook here (SRS §10.1 Documents)
    ext = {"application/pdf": ".pdf", "image/jpeg": ".jpg", "image/png": ".png"}[ct]
    key = f"{folder}/{uuid.uuid4().hex}{ext}"
    path = Path(settings.storage_dir) / key
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return {"file_key": key, "file_name": (file.filename or "upload")[:200], "content_type": ct,
            "size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def open_path(key: str) -> Path:
    base = Path(settings.storage_dir).resolve()
    p = (base / key).resolve()
    if base not in p.parents or not p.is_file():
        raise AppError(404, "NOT_FOUND", "File not found.")
    return p
