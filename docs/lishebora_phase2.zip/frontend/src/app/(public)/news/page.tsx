import { NewsCard } from "@/components/NewsCard";
import { publicGet } from "@/lib/server";
import type { NewsItem } from "@/lib/types";

export const metadata = { title: "News" };
export default async function News() {
  const items = (await publicGet<NewsItem[]>("/news")) ?? [];
  return (
    <section className="wrap sec"><h1>News &amp; updates</h1>
      {items.length ? <div className="grid g3" style={{ marginTop: 16 }}>{items.map((n) => <NewsCard key={n.slug} n={n} />)}</div>
        : <p className="muted">No news yet.</p>}
    </section>
  );
}
