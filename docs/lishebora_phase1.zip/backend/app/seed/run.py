"""Seed roles, permissions, the first super-admin, pilot geography, commodities and starter website content.
Safe to run repeatedly (idempotent).   Usage:  python -m app.seed.run  [--demo]"""
import sys
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal
from app.core.security import hash_password
from app.core.timeutil import utcnow
from app.models import (Commodity, ContentStatus, EventStatus, FaqItem, NewsPost, Organization, OrgType, Page,
                        Permission, ProcurementEvent, ProcurementMethod, Resource, Role, RolePermission, SiteBlock,
                        User, UserRole, UserStatus)
from app.seed.matrix import ACTIONS, DOMAINS, ROLES, all_permission_codes, role_permission_codes

COMMODITIES = [
    ("MZE-G1", "Maize (grade 1)", "cereals", "kg", "Cereal", {"max_moisture_pct": 13.5}, 150),
    ("RICE", "Rice", "cereals", "kg", "Cereal", {}, 120),
    ("BEAN-RC", "Beans (rosecoco)", "pulses", "kg", "Legume", {"max_moisture_pct": 14}, 40),
    ("GGRAM", "Green grams", "pulses", "kg", "Legume", {}, 40),
    ("VEG-LEAFY", "Leafy vegetables", "vegetables", "kg", "Vegetable", {}, 60),
    ("VEG-CAB", "Cabbage", "vegetables", "kg", "Vegetable", {}, 60),
    ("FRUIT-BAN", "Bananas", "fruit", "kg", "Fruit", {}, 80),
    ("EGGS", "Eggs", "animal_source", "tray", "Animal-source", {}, None),
    ("MILK", "Milk", "animal_source", "litre", "Animal-source", {}, None),
    ("OIL-VEG", "Cooking oil", "oils", "litre", "Oil", {}, 10),
]


def upsert_permissions_and_roles(db: Session):
    perms = {p.code: p for p in db.scalars(select(Permission)).all()}
    for code in sorted(all_permission_codes()):
        if code not in perms:
            d, a = code.split(":")
            perms[code] = Permission(code=code, domain=d, action=a, description=f"{a} — {DOMAINS[d]}")
            db.add(perms[code])
    db.flush()
    for key, (name, tier, scope, mfa, _cells, _cms) in ROLES.items():
        role = db.scalar(select(Role).where(Role.key == key))
        if role is None:
            role = Role(key=key, name=name, tier=tier, default_scope=scope, requires_mfa=mfa)
            db.add(role)
            db.flush()
        role.name, role.tier, role.default_scope, role.requires_mfa = name, tier, scope, mfa
        want = role_permission_codes(key)
        have = {rp.permission.code: rp for rp in role.permissions}
        for code in want - have.keys():
            role.permissions.append(RolePermission(permission=perms[code]))
        for code in have.keys() - want:
            role.permissions.remove(have[code])
    db.flush()


def org(db, type_, code, name, parent=None, **meta):
    o = db.scalar(select(Organization).where(Organization.code == code))
    if o is None:
        o = Organization(type=type_, code=code, name=name, parent_id=parent.id if parent else None, meta=meta)
        db.add(o)
        db.flush()
    return o


def seed_geography(db):
    ke = org(db, OrgType.country, "KE", "Kenya")
    org(db, OrgType.programme, "STEP", "STEP School Feeding Project", ke)
    counties = {}
    # Pilot counties are not yet confirmed (SRS §14 Q1) — placeholders until inception decisions.
    for i, letter in enumerate("AB", 1):
        c = org(db, OrgType.county, f"PILOT-{letter}", f"Pilot County {letter}", ke)
        sc = org(db, OrgType.sub_county, f"PILOT-{letter}-SC1", f"Pilot County {letter} · Sub-county 1", c)
        cl = org(db, OrgType.school_cluster, f"PILOT-{letter}-CL1", f"Cluster {i}", sc)
        org(db, OrgType.school, f"PILOT-{letter}-SCH001", f"Demo Primary School {i:03d}", cl, enrolment=None)
        counties[letter] = c
    return counties


def seed_admin(db):
    u = db.scalar(select(User).where(User.email == settings.seed_admin_email.lower()))
    if u is None:
        u = User(full_name="Super Administrator", email=settings.seed_admin_email.lower(),
                 password_hash=hash_password(settings.seed_admin_password), status=UserStatus.active)
        db.add(u)
        db.flush()
        role = db.scalar(select(Role).where(Role.key == "super_admin"))
        db.add(UserRole(user_id=u.id, role_id=role.id, org_id=None))
        print(f"Created super admin: {settings.seed_admin_email}  (password from SEED_ADMIN_PASSWORD — change it!)")
    return u


def seed_commodities(db):
    for code, name, cat, unit, fg, spec, portion in COMMODITIES:
        if db.scalar(select(Commodity).where(Commodity.code == code)) is None:
            db.add(Commodity(code=code, name=name, category=cat, unit=unit, food_group=fg, quality_spec=spec,
                             default_portion_g=portion))


def seed_cms(db, admin):
    now = utcnow()
    blocks = {
        "hero": {"eyebrow": "STEP School Feeding Project",
                 "title": "Nutritious school meals, sourced from local farmers",
                 "subtitle": "LisheBora connects schools with qualified local producers, cooperatives and aggregators. "
                             "Procurement is open, fair and traceable, and suppliers are paid faster.",
                 "cta_label": "Register as a supplier"},
        # Figures must come from signed-off MEAL data — placeholders until then.
        "stats": {"show": False, "items": [{"value": "[x]", "label": "schools in the pilot"},
                                           {"value": "[x]", "label": "registered suppliers"},
                                           {"value": "[x]%", "label": "of food sourced locally"},
                                           {"value": "[x]%", "label": "of contract value to women-, youth- and PWD-led suppliers"}]},
    }
    for key, data in blocks.items():
        if db.scalar(select(SiteBlock).where(SiteBlock.key == key)) is None:
            db.add(SiteBlock(key=key, data=data, published_data=data, status=ContentStatus.published,
                             published_at=now, published_by=admin.id))
    pages = {
        "about": ("About LisheBora", "LisheBora is being developed under the STEP School Feeding Project to strengthen "
                  "links between schools, local producers, aggregators and other suppliers.\n\n"
                  "*[Programme description to be supplied and approved by the programme team.]*"),
        "how-it-works": ("How it works", "## For suppliers\nRegister → get prequalified → receive alerts → submit sealed bids → "
                         "deliver → invoice and track payment.\n\n## For schools\nEnter enrolment, feeding days and menus → "
                         "confirm deliveries on your phone.\n\n## For counties\nApprove plans and budgets → run sourcing → "
                         "monitor delivery, payments and inclusion."),
        "privacy": ("Privacy notice", "*[Privacy notice aligned with the Data Protection Act, 2019 — to be supplied by legal.]*"),
        "terms": ("Terms of use", "*[Terms of use — to be supplied by legal.]*"),
    }
    for slug, (title, body) in pages.items():
        if db.scalar(select(Page).where(Page.slug == slug)) is None:
            db.add(Page(slug=slug, title=title, body=body, status=ContentStatus.published, published_at=now,
                        published_by=admin.id))
    if db.scalar(select(NewsPost.id).limit(1)) is None:
        db.add(NewsPost(slug="supplier-registration-opens", title="Supplier registration opens for pilot counties",
                        category="Announcement",
                        summary="Farmers, cooperatives, aggregators and traders in the pilot counties can now register "
                                "and apply for prequalification.",
                        body="*[Full article to be written by the content editor.]*",
                        status=ContentStatus.published, published_at=now, published_by=admin.id))
    if db.scalar(select(FaqItem.id).limit(1)) is None:
        for i, (q, a) in enumerate([
            ("Who can register as a supplier?", "Individual farmers, farmer groups and cooperatives, aggregators, traders, "
                                                "processors and MSMEs operating in the pilot counties."),
            ("I don't have a smartphone. Can I still take part?", "Yes. Assisted registration is available through county "
                                                                  "officers, aggregators and the helpdesk. Alerts are also sent by SMS."),
            ("How are winning bids chosen?", "Against the criteria published in each notice, such as price, quality, "
                                             "capacity, local sourcing and inclusion."),
            ("How long do payments take?", "Payment starts once goods are accepted and a valid invoice is submitted. "
                                           "You can track status in your portal."),
        ]):
            db.add(FaqItem(question=q, answer=a, sort_order=i))
    if db.scalar(select(Resource.id).limit(1)) is None:
        db.add(Resource(title="Supplier registration checklist", description="Documents you need to register",
                        is_published=True))


def seed_demo(db, counties):
    """Optional demo notices so the public site isn't empty during development."""
    now = utcnow()
    for ref, title, days, cats in [("RFQ-2026-A-0042", "Maize grade 1: Cluster 1 (demo)", 5, ["cereals"]),
                                   ("RFQ-2026-A-0043", "Beans & pulses: Term 3 (demo)", 12, ["pulses"])]:
        if db.scalar(select(ProcurementEvent).where(ProcurementEvent.reference == ref)) is None:
            db.add(ProcurementEvent(reference=ref, title=title, method=ProcurementMethod.rfq, county_id=counties["A"].id,
                                    eligibility="Prequalified: " + ", ".join(cats), categories=cats,
                                    closes_at=now + timedelta(days=days), status=EventStatus.open))


def main(demo: bool = False):
    db = SessionLocal()
    try:
        upsert_permissions_and_roles(db)
        counties = seed_geography(db)
        admin = seed_admin(db)
        seed_commodities(db)
        seed_cms(db, admin)
        if demo:
            seed_demo(db, counties)
        db.commit()
        print(f"Seed complete: {len(ROLES)} roles, {len(all_permission_codes())} permissions.")
    finally:
        db.close()


if __name__ == "__main__":
    main(demo="--demo" in sys.argv)
