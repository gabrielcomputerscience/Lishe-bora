"""System administration for the pilot (Phase 7): health, background jobs, message outbox, and bulk onboarding of
schools and users from CSV (always previewed first: nothing is written unless `commit=true`)."""
import csv
import io
import re
import uuid
from collections import Counter

from fastapi import APIRouter, Depends, File, Request, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.deps import Principal, require, require_any
from app.core.errors import AppError
from app.core.security import hash_password, new_opaque_token
from app.core.timeutil import utcnow
from app.models import Organization, OrgType, OutboundMessage, Role, SystemSetting, User, UserRole, UserStatus
from app.schemas.common import normalize_phone
from app.seed.matrix import CONFLICTING_ROLE_PAIRS
from app.services import audit, notify

router = APIRouter(prefix="/system", tags=["system administration"])
MAX_CSV = 2 * 1024 * 1024


async def _read_csv(file: UploadFile) -> list[dict]:
    raw = await file.read(MAX_CSV + 1)
    if len(raw) > MAX_CSV:
        raise AppError(413, "FILE_TOO_LARGE", "CSV files must be under 2 MB.")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    reader = csv.DictReader(io.StringIO(text))
    return [{(k or "").strip().lower(): (v or "").strip() for k, v in row.items()} for row in reader]


def _slug(s: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "-", s.upper()).strip("-")[:20]


# ---------------- status ----------------
@router.get("/status")
def status(p: Principal = Depends(require_any("iam:edit", "md:edit")), db: Session = Depends(get_db)):
    jobs = db.scalar(select(SystemSetting).where(SystemSetting.key == "jobs.last_run"))
    counts = dict(db.execute(select(OutboundMessage.status, func.count()).group_by(OutboundMessage.status)).all())
    failed = db.scalars(select(OutboundMessage).where(OutboundMessage.status == "failed").order_by(OutboundMessage.created_at.desc()).limit(20)).all()
    return {"env": settings.app_env, "database": db.bind.dialect.name, "notify_backend": settings.notify_backend,
            "email": "smtp" if settings.smtp_host else "console", "rate_limits": settings.rate_limit_enabled, "https_cookies": settings.cookie_secure,
            "jobs": (jobs.value if jobs else {}), "outbox": {"queued": counts.get("queued", 0), "sent": counts.get("sent", 0), "failed": counts.get("failed", 0)},
            "failed_messages": [{"id": m.id, "channel": m.channel, "to": notify.mask_phone(m.to) if m.channel == "sms" else m.to, "subject": m.subject,
                                 "attempts": m.attempts, "error": m.last_error, "created_at": m.created_at} for m in failed],
            "counts": {"users": db.scalar(select(func.count()).select_from(User)),
                       "schools": db.scalar(select(func.count()).select_from(Organization).where(Organization.type == OrgType.school))}}


@router.post("/outbox/{mid}/retry")
def retry(mid: uuid.UUID, p: Principal = Depends(require_any("iam:edit", "md:edit")), db: Session = Depends(get_db)):
    m = db.get(OutboundMessage, mid)
    if m is None or m.status != "failed":
        raise AppError(404, "NOT_FOUND", "No failed message with that id.")
    m.status, m.attempts, m.next_attempt_at = "queued", 0, utcnow()
    ok = notify.attempt(m)
    db.commit()
    return {"sent": ok, "error": m.last_error}


@router.post("/jobs/{task}/run")
def run_job(task: str, request: Request, p: Principal = Depends(require_any("iam:edit", "md:edit")), db: Session = Depends(get_db)):
    from app import jobs
    if task not in jobs.TASKS:
        raise AppError(404, "NOT_FOUND", "Unknown job.")
    audit.record(db, action="RUN_JOB", entity="job", entity_id=task, user=p.user, request=request)
    db.commit()
    return jobs.run([task])[task]


# ---------------- school import ----------------
@router.post("/import/schools")
async def import_schools(request: Request, commit: bool = False, file: UploadFile = File(...), p: Principal = Depends(require("md:create")),
                         db: Session = Depends(get_db)):
    """CSV columns: county, sub_county, school_code, school_name; optional: cluster, enrolment, lat, lng.
    Counties must already exist (by name or code). Sub-counties and clusters are created when missing; existing
    school codes are updated."""
    rows = await _read_csv(file)
    need = {"county", "sub_county", "school_code", "school_name"}
    if not rows or not need <= set(rows[0]):
        raise AppError(422, "VALIDATION_ERROR", "Columns needed: county, sub_county, school_code, school_name (optional: cluster, enrolment, lat, lng).")
    counties = {c.name.lower(): c for c in db.scalars(select(Organization).where(Organization.type == OrgType.county)).all()}
    counties |= {c.code.lower(): c for c in counties.values()}
    codes = Counter(r["school_code"].upper() for r in rows)
    result, created, updated = [], 0, 0
    for i, r in enumerate(rows, start=2):
        errs = []
        county = counties.get(r["county"].lower())
        if county is None:
            errs.append(f"Unknown county '{r['county']}'")
        code = r["school_code"].upper()
        if not code or not r["school_name"] or not r["sub_county"]:
            errs.append("School code, name and sub-county are required")
        if codes[code] > 1:
            errs.append("School code repeated in the file")
        enrol = None
        if r.get("enrolment"):
            try:
                enrol = int(float(r["enrolment"]))
                if enrol < 0 or enrol > 20000:
                    raise ValueError
            except ValueError:
                errs.append("Enrolment must be a number")
        gps = None
        if r.get("lat") or r.get("lng"):
            try:
                gps = {"lat": float(r["lat"]), "lng": float(r["lng"])}
                if not (-90 <= gps["lat"] <= 90 and -180 <= gps["lng"] <= 180):
                    raise ValueError
            except (ValueError, KeyError):
                errs.append("lat/lng must be decimal degrees")
        existing = db.scalar(select(Organization).where(Organization.code == code)) if code else None
        if existing is not None and existing.type != OrgType.school:
            errs.append(f"Code {code} is already used by a {existing.type.value}")
        action = "error" if errs else ("update" if existing else "create")
        result.append({"line": i, "school_code": code, "school_name": r["school_name"], "county": county.name if county else r["county"],
                       "action": action, "errors": errs})
        if errs or not commit:
            continue

        def ensure(type_, name, parent):
            c = f"{parent.code}-{_slug(name)}"
            o = db.scalar(select(Organization).where(Organization.code == c))
            if o is None:
                o = Organization(type=type_, name=name, code=c, parent_id=parent.id, meta={}, created_by=p.id)
                db.add(o)
                db.flush()
            return o
        sc = ensure(OrgType.sub_county, r["sub_county"], county)
        parent = ensure(OrgType.school_cluster, r["cluster"], sc) if r.get("cluster") else sc
        meta = dict(existing.meta or {}) if existing else {}
        if enrol is not None:
            meta["enrolment"] = enrol
        if gps:
            meta["gps"] = gps
        if existing:
            existing.name, existing.parent_id, existing.meta = r["school_name"], parent.id, meta
            updated += 1
        else:
            db.add(Organization(type=OrgType.school, name=r["school_name"], code=code, parent_id=parent.id, meta=meta, created_by=p.id))
            created += 1
    ok = all(x["action"] != "error" for x in result)
    if commit:
        if not ok:
            db.rollback()
            raise AppError(422, "IMPORT_ERRORS", "Fix the errors in the file first; nothing was imported.", [x for x in result if x["errors"]][:50])
        audit.record(db, action="IMPORT_SCHOOLS", entity="organization", entity_id="bulk", user=p.user,
                     after={"created": created, "updated": updated, "file": file.filename}, request=request)
        db.commit()
    return {"committed": commit and ok, "rows": len(result), "create": sum(x["action"] == "create" for x in result),
            "update": sum(x["action"] == "update" for x in result), "errors": sum(x["action"] == "error" for x in result), "lines": result}


# ---------------- user import ----------------
@router.post("/import/users")
async def import_users(request: Request, commit: bool = False, file: UploadFile = File(...), p: Principal = Depends(require("iam:create")),
                       db: Session = Depends(get_db)):
    """CSV columns: full_name, role, org_code and email and/or phone. Each new user gets a temporary password by SMS or
    email and must change it at first sign-in. Existing users get the extra role (segregation-of-duties rules apply)."""
    rows = await _read_csv(file)
    if not rows or not {"full_name", "role", "org_code"} <= set(rows[0]) or not ({"email", "phone"} & set(rows[0])):
        raise AppError(422, "VALIDATION_ERROR", "Columns needed: full_name, role, org_code and email and/or phone.")
    roles = {r.key: r for r in db.scalars(select(Role)).all()}
    staff_only = {"supplier", "farmer_group", "aggregator"}      # suppliers self-register (FR-SUP-01)
    blocked = {"super_admin"} if "super_admin" not in {ur.role.key for ur in p.user.roles if ur.is_active} else set()
    seen: dict[str, set] = {}
    result, created, added = [], 0, 0
    for i, r in enumerate(rows, start=2):
        errs = []
        role = roles.get(r["role"].strip().lower())
        if role is None:
            errs.append(f"Unknown role '{r['role']}'")
        elif role.key in staff_only:
            errs.append("Suppliers register themselves on the website")
        elif role.key in blocked:
            errs.append("Only a super administrator can create super administrators")
        org = db.scalar(select(Organization).where(Organization.code == r["org_code"].upper())) if r.get("org_code") else None
        if r.get("org_code") and org is None:
            errs.append(f"Unknown organisation code '{r['org_code']}'")
        email = (r.get("email") or "").lower() or None
        phone = None
        try:
            phone = normalize_phone(r.get("phone") or None)
        except ValueError as e:
            errs.append(str(e))
        if not email and not phone:
            errs.append("Email or phone is required")
        if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            errs.append("Invalid email")
        if len(r.get("full_name", "")) < 3:
            errs.append("Full name is required")
        key = email or phone or f"line{i}"
        user = db.scalar(select(User).where((User.email == email) if email else (User.phone == phone))) if (email or phone) else None
        have = set(seen.get(key, set())) | ({ur.role.key for ur in user.roles if ur.is_active} if user else set())
        if role:
            for a, b in CONFLICTING_ROLE_PAIRS:
                if (role.key == a and b in have) or (role.key == b and a in have):
                    errs.append(f"{role.key} conflicts with {b if role.key == a else a} (segregation of duties)")
            seen.setdefault(key, set()).add(role.key)
        action = "error" if errs else ("add_role" if user else "create")
        result.append({"line": i, "full_name": r.get("full_name"), "contact": email or notify.mask_phone(phone), "role": r["role"],
                       "org": org.name if org else None, "action": action, "errors": errs})
        if errs or not commit:
            continue
        if user is None:
            temp = new_opaque_token()[:14] + "A1"
            user = User(full_name=r["full_name"], email=email, phone=phone, password_hash=hash_password(temp), status=UserStatus.active,
                        created_by=p.id)
            db.add(user)
            db.flush()
            msg = f"You have been invited to LisheBora as {role.name}. Temporary password: {temp} (change it after signing in)."
            if email:
                notify.email(db, email, "LisheBora invitation", msg, sensitive=True)
            else:
                notify.sms(db, phone, msg, sensitive=True)
            created += 1
        else:
            added += 1
        db.add(UserRole(user_id=user.id, role_id=role.id, org_id=org.id if org else None, created_by=p.id))
        db.flush()
    ok = all(x["action"] != "error" for x in result)
    if commit:
        if not ok:
            db.rollback()
            raise AppError(422, "IMPORT_ERRORS", "Fix the errors in the file first; nothing was imported.", [x for x in result if x["errors"]][:50])
        audit.record(db, action="IMPORT_USERS", entity="user", entity_id="bulk", user=p.user,
                     after={"created": created, "roles_added": added, "file": file.filename}, request=request)
        db.commit()
    return {"committed": commit and ok, "rows": len(result), "create": sum(x["action"] == "create" for x in result),
            "add_role": sum(x["action"] == "add_role" for x in result), "errors": sum(x["action"] == "error" for x in result), "lines": result}
