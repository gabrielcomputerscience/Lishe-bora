// Colours for the nutrition groups, drawn from the AATF palette and the homepage wave colours.
export const GROUP_COLOUR: Record<string, [string, string]> = {
  "Cereal": ["#F9B916", "#8A5A2B"], "Legume": ["#8A5A2B", "#F9B916"], "Vegetable": ["#75BA43", "#2F4520"],
  "Fruit": ["#E8892B", "#8A5A2B"], "Roots & tubers": ["#AB822D", "#2F4520"], "Animal-source": ["#1F5FA8", "#1FB5C9"],
  "Oil": ["#1FB5C9", "#1F5FA8"], "": ["#9AA58F", "#4B5842"],
};
export const colourFor = (group: string) => GROUP_COLOUR[group] ?? GROUP_COLOUR[""];
